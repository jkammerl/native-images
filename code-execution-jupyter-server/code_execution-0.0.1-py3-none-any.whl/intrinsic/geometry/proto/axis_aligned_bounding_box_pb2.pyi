from intrinsic.math.proto import vector2_pb2 as _vector2_pb2
from intrinsic.math.proto import vector3_pb2 as _vector3_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AxisAlignedBoundingBox(_message.Message):
    __slots__ = ("min_points", "max_points")
    MIN_POINTS_FIELD_NUMBER: _ClassVar[int]
    MAX_POINTS_FIELD_NUMBER: _ClassVar[int]
    min_points: _containers.RepeatedScalarFieldContainer[float]
    max_points: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, min_points: _Optional[_Iterable[float]] = ..., max_points: _Optional[_Iterable[float]] = ...) -> None: ...

class AxisAlignedBoundingBox2(_message.Message):
    __slots__ = ("min", "max")
    MIN_FIELD_NUMBER: _ClassVar[int]
    MAX_FIELD_NUMBER: _ClassVar[int]
    min: _vector2_pb2.Vector2
    max: _vector2_pb2.Vector2
    def __init__(self, min: _Optional[_Union[_vector2_pb2.Vector2, _Mapping]] = ..., max: _Optional[_Union[_vector2_pb2.Vector2, _Mapping]] = ...) -> None: ...

class AxisAlignedBoundingBox3(_message.Message):
    __slots__ = ("min", "max")
    MIN_FIELD_NUMBER: _ClassVar[int]
    MAX_FIELD_NUMBER: _ClassVar[int]
    min: _vector3_pb2.Vector3
    max: _vector3_pb2.Vector3
    def __init__(self, min: _Optional[_Union[_vector3_pb2.Vector3, _Mapping]] = ..., max: _Optional[_Union[_vector3_pb2.Vector3, _Mapping]] = ...) -> None: ...
