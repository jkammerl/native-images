from intrinsic.geometry.proto import lazy_exact_geometry_pb2 as _lazy_exact_geometry_pb2
from intrinsic.geometry.proto import renderable_pb2 as _renderable_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Geometry(_message.Message):
    __slots__ = ("exact_geometry", "renderable", "generated_renderable")
    EXACT_GEOMETRY_FIELD_NUMBER: _ClassVar[int]
    RENDERABLE_FIELD_NUMBER: _ClassVar[int]
    GENERATED_RENDERABLE_FIELD_NUMBER: _ClassVar[int]
    exact_geometry: _lazy_exact_geometry_pb2.LazyExactGeometry
    renderable: _renderable_pb2.Renderable
    generated_renderable: _renderable_pb2.Renderable
    def __init__(self, exact_geometry: _Optional[_Union[_lazy_exact_geometry_pb2.LazyExactGeometry, _Mapping]] = ..., renderable: _Optional[_Union[_renderable_pb2.Renderable, _Mapping]] = ..., generated_renderable: _Optional[_Union[_renderable_pb2.Renderable, _Mapping]] = ...) -> None: ...
