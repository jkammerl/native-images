from google.api import annotations_pb2 as _annotations_pb2
from intrinsic.geometry.proto import geometry_service_types_pb2 as _geometry_service_types_pb2
from intrinsic.geometry.proto import geometry_storage_refs_pb2 as _geometry_storage_refs_pb2
from intrinsic.geometry.proto.v1 import geometry_pb2 as _geometry_pb2
from intrinsic.geometry.proto.v1 import geometry_storage_refs_pb2 as _geometry_storage_refs_pb2_1
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetGeometryRequest(_message.Message):
    __slots__ = ("geometry_storage_refs_v0", "geometry_storage_refs")
    GEOMETRY_STORAGE_REFS_V0_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_STORAGE_REFS_FIELD_NUMBER: _ClassVar[int]
    geometry_storage_refs_v0: _geometry_storage_refs_pb2.GeometryStorageRefs
    geometry_storage_refs: _geometry_storage_refs_pb2_1.GeometryStorageRefs
    def __init__(self, geometry_storage_refs_v0: _Optional[_Union[_geometry_storage_refs_pb2.GeometryStorageRefs, _Mapping]] = ..., geometry_storage_refs: _Optional[_Union[_geometry_storage_refs_pb2_1.GeometryStorageRefs, _Mapping]] = ...) -> None: ...

class GetRenderableRequest(_message.Message):
    __slots__ = ("geometry_storage_refs_v0", "geometry_storage_refs", "lod_level")
    GEOMETRY_STORAGE_REFS_V0_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_STORAGE_REFS_FIELD_NUMBER: _ClassVar[int]
    LOD_LEVEL_FIELD_NUMBER: _ClassVar[int]
    geometry_storage_refs_v0: _geometry_storage_refs_pb2.GeometryStorageRefs
    geometry_storage_refs: _geometry_storage_refs_pb2_1.GeometryStorageRefs
    lod_level: int
    def __init__(self, geometry_storage_refs_v0: _Optional[_Union[_geometry_storage_refs_pb2.GeometryStorageRefs, _Mapping]] = ..., geometry_storage_refs: _Optional[_Union[_geometry_storage_refs_pb2_1.GeometryStorageRefs, _Mapping]] = ..., lod_level: _Optional[int] = ...) -> None: ...

class CreateGeometryRequest(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: _geometry_service_types_pb2.GeometryData
    def __init__(self, data: _Optional[_Union[_geometry_service_types_pb2.GeometryData, _Mapping]] = ...) -> None: ...
