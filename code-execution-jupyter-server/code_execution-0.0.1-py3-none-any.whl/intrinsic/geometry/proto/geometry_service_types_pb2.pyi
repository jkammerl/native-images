from intrinsic.geometry.proto import geometry_pb2 as _geometry_pb2
from intrinsic.geometry.proto import geometry_storage_refs_pb2 as _geometry_storage_refs_pb2
from intrinsic.geometry.proto import lazy_exact_geometry_pb2 as _lazy_exact_geometry_pb2
from intrinsic.geometry.proto import renderable_pb2 as _renderable_pb2
from intrinsic.geometry.proto.v1 import geometry_storage_refs_pb2 as _geometry_storage_refs_pb2_1
from intrinsic.geometry.proto.v1 import inline_geometry_pb2 as _inline_geometry_pb2
from intrinsic.geometry.proto.v1 import renderable_pb2 as _renderable_pb2_1
from intrinsic.geometry.proto.v1 import transformed_primitive_shape_set_pb2 as _transformed_primitive_shape_set_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GeometryWithMetadata(_message.Message):
    __slots__ = ("geometry_storage_refs_v0", "geometry_storage_refs", "geometry_v0", "inline_geometry")
    GEOMETRY_STORAGE_REFS_V0_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_STORAGE_REFS_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_V0_FIELD_NUMBER: _ClassVar[int]
    INLINE_GEOMETRY_FIELD_NUMBER: _ClassVar[int]
    geometry_storage_refs_v0: _geometry_storage_refs_pb2.GeometryStorageRefs
    geometry_storage_refs: _geometry_storage_refs_pb2_1.GeometryStorageRefs
    geometry_v0: _geometry_pb2.Geometry
    inline_geometry: _inline_geometry_pb2.InlineGeometry
    def __init__(self, geometry_storage_refs_v0: _Optional[_Union[_geometry_storage_refs_pb2.GeometryStorageRefs, _Mapping]] = ..., geometry_storage_refs: _Optional[_Union[_geometry_storage_refs_pb2_1.GeometryStorageRefs, _Mapping]] = ..., geometry_v0: _Optional[_Union[_geometry_pb2.Geometry, _Mapping]] = ..., inline_geometry: _Optional[_Union[_inline_geometry_pb2.InlineGeometry, _Mapping]] = ...) -> None: ...

class RenderableWithMetadata(_message.Message):
    __slots__ = ("geometry_storage_refs_v0", "geometry_storage_refs", "lod_level", "renderable_v0", "renderable")
    GEOMETRY_STORAGE_REFS_V0_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_STORAGE_REFS_FIELD_NUMBER: _ClassVar[int]
    LOD_LEVEL_FIELD_NUMBER: _ClassVar[int]
    RENDERABLE_V0_FIELD_NUMBER: _ClassVar[int]
    RENDERABLE_FIELD_NUMBER: _ClassVar[int]
    geometry_storage_refs_v0: _geometry_storage_refs_pb2.GeometryStorageRefs
    geometry_storage_refs: _geometry_storage_refs_pb2_1.GeometryStorageRefs
    lod_level: int
    renderable_v0: _renderable_pb2.Renderable
    renderable: _renderable_pb2_1.Renderable
    def __init__(self, geometry_storage_refs_v0: _Optional[_Union[_geometry_storage_refs_pb2.GeometryStorageRefs, _Mapping]] = ..., geometry_storage_refs: _Optional[_Union[_geometry_storage_refs_pb2_1.GeometryStorageRefs, _Mapping]] = ..., lod_level: _Optional[int] = ..., renderable_v0: _Optional[_Union[_renderable_pb2.Renderable, _Mapping]] = ..., renderable: _Optional[_Union[_renderable_pb2_1.Renderable, _Mapping]] = ...) -> None: ...

class GeometryData(_message.Message):
    __slots__ = ("geometry_v0", "inline_geometry", "primitive_set_v0", "primitive_set", "obj_data", "gltf_bytes", "stl_bytes")
    GEOMETRY_V0_FIELD_NUMBER: _ClassVar[int]
    INLINE_GEOMETRY_FIELD_NUMBER: _ClassVar[int]
    PRIMITIVE_SET_V0_FIELD_NUMBER: _ClassVar[int]
    PRIMITIVE_SET_FIELD_NUMBER: _ClassVar[int]
    OBJ_DATA_FIELD_NUMBER: _ClassVar[int]
    GLTF_BYTES_FIELD_NUMBER: _ClassVar[int]
    STL_BYTES_FIELD_NUMBER: _ClassVar[int]
    geometry_v0: _geometry_pb2.Geometry
    inline_geometry: _inline_geometry_pb2.InlineGeometry
    primitive_set_v0: _lazy_exact_geometry_pb2.PrimitiveShapeSet
    primitive_set: _transformed_primitive_shape_set_pb2.TransformedPrimitiveShapeSet
    obj_data: bytes
    gltf_bytes: bytes
    stl_bytes: bytes
    def __init__(self, geometry_v0: _Optional[_Union[_geometry_pb2.Geometry, _Mapping]] = ..., inline_geometry: _Optional[_Union[_inline_geometry_pb2.InlineGeometry, _Mapping]] = ..., primitive_set_v0: _Optional[_Union[_lazy_exact_geometry_pb2.PrimitiveShapeSet, _Mapping]] = ..., primitive_set: _Optional[_Union[_transformed_primitive_shape_set_pb2.TransformedPrimitiveShapeSet, _Mapping]] = ..., obj_data: _Optional[bytes] = ..., gltf_bytes: _Optional[bytes] = ..., stl_bytes: _Optional[bytes] = ...) -> None: ...
