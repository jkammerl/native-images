from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class GeometryStorageRefs(_message.Message):
    __slots__ = ("fingerprint", "geometry_ref", "renderable_ref")
    FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_REF_FIELD_NUMBER: _ClassVar[int]
    RENDERABLE_REF_FIELD_NUMBER: _ClassVar[int]
    fingerprint: str
    geometry_ref: str
    renderable_ref: str
    def __init__(self, fingerprint: _Optional[str] = ..., geometry_ref: _Optional[str] = ..., renderable_ref: _Optional[str] = ...) -> None: ...
