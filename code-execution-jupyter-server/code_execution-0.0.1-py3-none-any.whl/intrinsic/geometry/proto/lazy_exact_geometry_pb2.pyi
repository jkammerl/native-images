from intrinsic.geometry.proto import mesh_octree_wrapping_pb2 as _mesh_octree_wrapping_pb2
from intrinsic.geometry.proto import primitives_pb2 as _primitives_pb2
from intrinsic.geometry.proto import triangle_mesh_pb2 as _triangle_mesh_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class LazyExactGeometry(_message.Message):
    __slots__ = ("triangle_mesh", "mesh_octree_wrapping", "primitive_set")
    TRIANGLE_MESH_FIELD_NUMBER: _ClassVar[int]
    MESH_OCTREE_WRAPPING_FIELD_NUMBER: _ClassVar[int]
    PRIMITIVE_SET_FIELD_NUMBER: _ClassVar[int]
    triangle_mesh: _triangle_mesh_pb2.TriangleMesh
    mesh_octree_wrapping: _mesh_octree_wrapping_pb2.MeshOctreeWrapping
    primitive_set: PrimitiveShapeSet
    def __init__(self, triangle_mesh: _Optional[_Union[_triangle_mesh_pb2.TriangleMesh, _Mapping]] = ..., mesh_octree_wrapping: _Optional[_Union[_mesh_octree_wrapping_pb2.MeshOctreeWrapping, _Mapping]] = ..., primitive_set: _Optional[_Union[PrimitiveShapeSet, _Mapping]] = ...) -> None: ...

class PrimitiveShape(_message.Message):
    __slots__ = ("box", "cylinder", "sphere", "ellipsoid", "capsule", "frustum")
    BOX_FIELD_NUMBER: _ClassVar[int]
    CYLINDER_FIELD_NUMBER: _ClassVar[int]
    SPHERE_FIELD_NUMBER: _ClassVar[int]
    ELLIPSOID_FIELD_NUMBER: _ClassVar[int]
    CAPSULE_FIELD_NUMBER: _ClassVar[int]
    FRUSTUM_FIELD_NUMBER: _ClassVar[int]
    box: _primitives_pb2.Box
    cylinder: _primitives_pb2.Cylinder
    sphere: _primitives_pb2.Sphere
    ellipsoid: _primitives_pb2.Ellipsoid
    capsule: _primitives_pb2.Capsule
    frustum: _primitives_pb2.Frustum
    def __init__(self, box: _Optional[_Union[_primitives_pb2.Box, _Mapping]] = ..., cylinder: _Optional[_Union[_primitives_pb2.Cylinder, _Mapping]] = ..., sphere: _Optional[_Union[_primitives_pb2.Sphere, _Mapping]] = ..., ellipsoid: _Optional[_Union[_primitives_pb2.Ellipsoid, _Mapping]] = ..., capsule: _Optional[_Union[_primitives_pb2.Capsule, _Mapping]] = ..., frustum: _Optional[_Union[_primitives_pb2.Frustum, _Mapping]] = ...) -> None: ...

class PrimitiveShapeSet(_message.Message):
    __slots__ = ("primitives",)
    PRIMITIVES_FIELD_NUMBER: _ClassVar[int]
    primitives: _containers.RepeatedCompositeFieldContainer[PrimitiveShape]
    def __init__(self, primitives: _Optional[_Iterable[_Union[PrimitiveShape, _Mapping]]] = ...) -> None: ...
