from intrinsic.geometry.proto import octree_pb2 as _octree_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MeshOctreeWrapping(_message.Message):
    __slots__ = ("octree", "morton_to_primitives")
    class MortonToPrimitiveEntry(_message.Message):
        __slots__ = ("code", "primitives")
        CODE_FIELD_NUMBER: _ClassVar[int]
        PRIMITIVES_FIELD_NUMBER: _ClassVar[int]
        code: int
        primitives: _containers.RepeatedScalarFieldContainer[int]
        def __init__(self, code: _Optional[int] = ..., primitives: _Optional[_Iterable[int]] = ...) -> None: ...
    OCTREE_FIELD_NUMBER: _ClassVar[int]
    MORTON_TO_PRIMITIVES_FIELD_NUMBER: _ClassVar[int]
    octree: _octree_pb2.Octree
    morton_to_primitives: _containers.RepeatedCompositeFieldContainer[MeshOctreeWrapping.MortonToPrimitiveEntry]
    def __init__(self, octree: _Optional[_Union[_octree_pb2.Octree, _Mapping]] = ..., morton_to_primitives: _Optional[_Iterable[_Union[MeshOctreeWrapping.MortonToPrimitiveEntry, _Mapping]]] = ...) -> None: ...
