from intrinsic.geometry.proto import axis_aligned_bounding_box_pb2 as _axis_aligned_bounding_box_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Octree(_message.Message):
    __slots__ = ("is_child_k_leaf", "has_child_k", "morton_list", "workspace_bounding_box", "max_depth")
    IS_CHILD_K_LEAF_FIELD_NUMBER: _ClassVar[int]
    HAS_CHILD_K_FIELD_NUMBER: _ClassVar[int]
    MORTON_LIST_FIELD_NUMBER: _ClassVar[int]
    WORKSPACE_BOUNDING_BOX_FIELD_NUMBER: _ClassVar[int]
    MAX_DEPTH_FIELD_NUMBER: _ClassVar[int]
    is_child_k_leaf: bytes
    has_child_k: bytes
    morton_list: _containers.RepeatedScalarFieldContainer[int]
    workspace_bounding_box: _axis_aligned_bounding_box_pb2.AxisAlignedBoundingBox3
    max_depth: int
    def __init__(self, is_child_k_leaf: _Optional[bytes] = ..., has_child_k: _Optional[bytes] = ..., morton_list: _Optional[_Iterable[int]] = ..., workspace_bounding_box: _Optional[_Union[_axis_aligned_bounding_box_pb2.AxisAlignedBoundingBox3, _Mapping]] = ..., max_depth: _Optional[int] = ...) -> None: ...
