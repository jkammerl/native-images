from intrinsic.math.proto import vector3_pb2 as _vector3_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Box(_message.Message):
    __slots__ = ("size",)
    SIZE_FIELD_NUMBER: _ClassVar[int]
    size: _vector3_pb2.Vector3
    def __init__(self, size: _Optional[_Union[_vector3_pb2.Vector3, _Mapping]] = ...) -> None: ...

class Cylinder(_message.Message):
    __slots__ = ("length", "radius")
    LENGTH_FIELD_NUMBER: _ClassVar[int]
    RADIUS_FIELD_NUMBER: _ClassVar[int]
    length: float
    radius: float
    def __init__(self, length: _Optional[float] = ..., radius: _Optional[float] = ...) -> None: ...

class Sphere(_message.Message):
    __slots__ = ("radius",)
    RADIUS_FIELD_NUMBER: _ClassVar[int]
    radius: float
    def __init__(self, radius: _Optional[float] = ...) -> None: ...

class Ellipsoid(_message.Message):
    __slots__ = ("radii",)
    RADII_FIELD_NUMBER: _ClassVar[int]
    radii: _vector3_pb2.Vector3
    def __init__(self, radii: _Optional[_Union[_vector3_pb2.Vector3, _Mapping]] = ...) -> None: ...

class Capsule(_message.Message):
    __slots__ = ("length", "radius")
    LENGTH_FIELD_NUMBER: _ClassVar[int]
    RADIUS_FIELD_NUMBER: _ClassVar[int]
    length: float
    radius: float
    def __init__(self, length: _Optional[float] = ..., radius: _Optional[float] = ...) -> None: ...

class Frustum(_message.Message):
    __slots__ = ("x_angle", "y_angle", "min_z_distance", "max_z_distance")
    X_ANGLE_FIELD_NUMBER: _ClassVar[int]
    Y_ANGLE_FIELD_NUMBER: _ClassVar[int]
    MIN_Z_DISTANCE_FIELD_NUMBER: _ClassVar[int]
    MAX_Z_DISTANCE_FIELD_NUMBER: _ClassVar[int]
    x_angle: float
    y_angle: float
    min_z_distance: float
    max_z_distance: float
    def __init__(self, x_angle: _Optional[float] = ..., y_angle: _Optional[float] = ..., min_z_distance: _Optional[float] = ..., max_z_distance: _Optional[float] = ...) -> None: ...
