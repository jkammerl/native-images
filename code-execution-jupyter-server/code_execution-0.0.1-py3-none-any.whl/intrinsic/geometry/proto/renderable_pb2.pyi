from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class Renderable(_message.Message):
    __slots__ = ("gltf_string",)
    GLTF_STRING_FIELD_NUMBER: _ClassVar[int]
    gltf_string: bytes
    def __init__(self, gltf_string: _Optional[bytes] = ...) -> None: ...
