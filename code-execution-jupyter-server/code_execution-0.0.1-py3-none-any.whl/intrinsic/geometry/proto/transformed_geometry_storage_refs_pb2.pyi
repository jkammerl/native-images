from intrinsic.geometry.proto import geometry_storage_refs_pb2 as _geometry_storage_refs_pb2
from intrinsic.math.proto import matrix_pb2 as _matrix_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TransformedGeometryStorageRefs(_message.Message):
    __slots__ = ("geometry_storage_refs", "ref_t_shape_aff")
    GEOMETRY_STORAGE_REFS_FIELD_NUMBER: _ClassVar[int]
    REF_T_SHAPE_AFF_FIELD_NUMBER: _ClassVar[int]
    geometry_storage_refs: _geometry_storage_refs_pb2.GeometryStorageRefs
    ref_t_shape_aff: _matrix_pb2.Matrixd
    def __init__(self, geometry_storage_refs: _Optional[_Union[_geometry_storage_refs_pb2.GeometryStorageRefs, _Mapping]] = ..., ref_t_shape_aff: _Optional[_Union[_matrix_pb2.Matrixd, _Mapping]] = ...) -> None: ...
