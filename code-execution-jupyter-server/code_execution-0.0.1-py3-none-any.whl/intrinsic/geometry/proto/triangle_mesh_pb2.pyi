from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class TriangleMesh(_message.Message):
    __slots__ = ("vertices", "faces")
    VERTICES_FIELD_NUMBER: _ClassVar[int]
    FACES_FIELD_NUMBER: _ClassVar[int]
    vertices: _containers.RepeatedScalarFieldContainer[float]
    faces: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, vertices: _Optional[_Iterable[float]] = ..., faces: _Optional[_Iterable[int]] = ...) -> None: ...
