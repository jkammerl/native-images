from intrinsic.geometry.proto.v1 import geometry_options_pb2 as _geometry_options_pb2
from intrinsic.geometry.proto.v1 import octree_wrapping_pb2 as _octree_wrapping_pb2
from intrinsic.geometry.proto.v1 import point_cloud_pb2 as _point_cloud_pb2
from intrinsic.geometry.proto.v1 import transformed_primitive_shape_set_pb2 as _transformed_primitive_shape_set_pb2
from intrinsic.geometry.proto.v1 import triangle_mesh_pb2 as _triangle_mesh_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ExactGeometry(_message.Message):
    __slots__ = ("primitive_set", "triangle_mesh", "point_cloud", "octree_wrapping", "options")
    PRIMITIVE_SET_FIELD_NUMBER: _ClassVar[int]
    TRIANGLE_MESH_FIELD_NUMBER: _ClassVar[int]
    POINT_CLOUD_FIELD_NUMBER: _ClassVar[int]
    OCTREE_WRAPPING_FIELD_NUMBER: _ClassVar[int]
    OPTIONS_FIELD_NUMBER: _ClassVar[int]
    primitive_set: _transformed_primitive_shape_set_pb2.TransformedPrimitiveShapeSet
    triangle_mesh: _triangle_mesh_pb2.TriangleMesh
    point_cloud: _point_cloud_pb2.PointCloud
    octree_wrapping: _octree_wrapping_pb2.OctreeWrapping
    options: _geometry_options_pb2.GeometryOptions
    def __init__(self, primitive_set: _Optional[_Union[_transformed_primitive_shape_set_pb2.TransformedPrimitiveShapeSet, _Mapping]] = ..., triangle_mesh: _Optional[_Union[_triangle_mesh_pb2.TriangleMesh, _Mapping]] = ..., point_cloud: _Optional[_Union[_point_cloud_pb2.PointCloud, _Mapping]] = ..., octree_wrapping: _Optional[_Union[_octree_wrapping_pb2.OctreeWrapping, _Mapping]] = ..., options: _Optional[_Union[_geometry_options_pb2.GeometryOptions, _Mapping]] = ...) -> None: ...
