from intrinsic.math.proto import matrix_pb2 as _matrix_pb2
from intrinsic.math.proto import vector3_pb2 as _vector3_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GeometricTransform(_message.Message):
    __slots__ = ("matrix4d", "trs")
    class TRS(_message.Message):
        __slots__ = ("translation", "rotation_rpy", "scale")
        class RotationRPY(_message.Message):
            __slots__ = ("r", "p", "y")
            R_FIELD_NUMBER: _ClassVar[int]
            P_FIELD_NUMBER: _ClassVar[int]
            Y_FIELD_NUMBER: _ClassVar[int]
            r: float
            p: float
            y: float
            def __init__(self, r: _Optional[float] = ..., p: _Optional[float] = ..., y: _Optional[float] = ...) -> None: ...
        TRANSLATION_FIELD_NUMBER: _ClassVar[int]
        ROTATION_RPY_FIELD_NUMBER: _ClassVar[int]
        SCALE_FIELD_NUMBER: _ClassVar[int]
        translation: _vector3_pb2.Vector3
        rotation_rpy: GeometricTransform.TRS.RotationRPY
        scale: _vector3_pb2.Vector3
        def __init__(self, translation: _Optional[_Union[_vector3_pb2.Vector3, _Mapping]] = ..., rotation_rpy: _Optional[_Union[GeometricTransform.TRS.RotationRPY, _Mapping]] = ..., scale: _Optional[_Union[_vector3_pb2.Vector3, _Mapping]] = ...) -> None: ...
    MATRIX4D_FIELD_NUMBER: _ClassVar[int]
    TRS_FIELD_NUMBER: _ClassVar[int]
    matrix4d: _matrix_pb2.Matrixd
    trs: GeometricTransform.TRS
    def __init__(self, matrix4d: _Optional[_Union[_matrix_pb2.Matrixd, _Mapping]] = ..., trs: _Optional[_Union[GeometricTransform.TRS, _Mapping]] = ...) -> None: ...
