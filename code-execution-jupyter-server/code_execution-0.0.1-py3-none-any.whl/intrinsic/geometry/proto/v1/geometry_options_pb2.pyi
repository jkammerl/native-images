from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class GeometryOptions(_message.Message):
    __slots__ = ("fill_inside_for_distance_queries", "simulation_convex_decomposition_resolution")
    FILL_INSIDE_FOR_DISTANCE_QUERIES_FIELD_NUMBER: _ClassVar[int]
    SIMULATION_CONVEX_DECOMPOSITION_RESOLUTION_FIELD_NUMBER: _ClassVar[int]
    fill_inside_for_distance_queries: bool
    simulation_convex_decomposition_resolution: int
    def __init__(self, fill_inside_for_distance_queries: _Optional[bool] = ..., simulation_convex_decomposition_resolution: _Optional[int] = ...) -> None: ...
