from intrinsic.geometry.proto.v1 import geometry_storage_refs_pb2 as _geometry_storage_refs_pb2
from intrinsic.geometry.proto.v1 import inline_geometry_pb2 as _inline_geometry_pb2
from intrinsic.geometry.proto.v1 import material_pb2 as _material_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GeometryProvenance(_message.Message):
    __slots__ = ("human_readable_update_reason", "geometry_data_uri", "geometry_data")
    HUMAN_READABLE_UPDATE_REASON_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_DATA_URI_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_DATA_FIELD_NUMBER: _ClassVar[int]
    human_readable_update_reason: str
    geometry_data_uri: str
    geometry_data: Geometry
    def __init__(self, human_readable_update_reason: _Optional[str] = ..., geometry_data_uri: _Optional[str] = ..., geometry_data: _Optional[_Union[Geometry, _Mapping]] = ...) -> None: ...

class Geometry(_message.Message):
    __slots__ = ("geo_ref", "inline_geometry_data", "material_overrides", "provenance")
    GEO_REF_FIELD_NUMBER: _ClassVar[int]
    INLINE_GEOMETRY_DATA_FIELD_NUMBER: _ClassVar[int]
    MATERIAL_OVERRIDES_FIELD_NUMBER: _ClassVar[int]
    PROVENANCE_FIELD_NUMBER: _ClassVar[int]
    geo_ref: _geometry_storage_refs_pb2.GeometryStorageRefs
    inline_geometry_data: _inline_geometry_pb2.InlineGeometry
    material_overrides: _material_pb2.MaterialProperties
    provenance: GeometryProvenance
    def __init__(self, geo_ref: _Optional[_Union[_geometry_storage_refs_pb2.GeometryStorageRefs, _Mapping]] = ..., inline_geometry_data: _Optional[_Union[_inline_geometry_pb2.InlineGeometry, _Mapping]] = ..., material_overrides: _Optional[_Union[_material_pb2.MaterialProperties, _Mapping]] = ..., provenance: _Optional[_Union[GeometryProvenance, _Mapping]] = ...) -> None: ...
