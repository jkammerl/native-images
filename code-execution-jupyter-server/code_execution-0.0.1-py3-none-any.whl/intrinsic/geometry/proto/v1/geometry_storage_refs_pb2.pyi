from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class GeometryStorageRefs(_message.Message):
    __slots__ = ("exact_geometry_ref", "renderable_ref", "keep_renderable")
    EXACT_GEOMETRY_REF_FIELD_NUMBER: _ClassVar[int]
    RENDERABLE_REF_FIELD_NUMBER: _ClassVar[int]
    KEEP_RENDERABLE_FIELD_NUMBER: _ClassVar[int]
    exact_geometry_ref: str
    renderable_ref: str
    keep_renderable: bool
    def __init__(self, exact_geometry_ref: _Optional[str] = ..., renderable_ref: _Optional[str] = ..., keep_renderable: _Optional[bool] = ...) -> None: ...
