from google.type import color_pb2 as _color_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MaterialProperties(_message.Message):
    __slots__ = ("base_color", "metalness", "roughness", "transmission")
    BASE_COLOR_FIELD_NUMBER: _ClassVar[int]
    METALNESS_FIELD_NUMBER: _ClassVar[int]
    ROUGHNESS_FIELD_NUMBER: _ClassVar[int]
    TRANSMISSION_FIELD_NUMBER: _ClassVar[int]
    base_color: _color_pb2.Color
    metalness: float
    roughness: float
    transmission: float
    def __init__(self, base_color: _Optional[_Union[_color_pb2.Color, _Mapping]] = ..., metalness: _Optional[float] = ..., roughness: _Optional[float] = ..., transmission: _Optional[float] = ...) -> None: ...
