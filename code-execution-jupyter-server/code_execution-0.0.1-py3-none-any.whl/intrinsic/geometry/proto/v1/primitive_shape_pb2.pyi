from intrinsic.geometry.proto.v1 import primitives_pb2 as _primitives_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PrimitiveShape(_message.Message):
    __slots__ = ("box", "capsule", "cylinder", "ellipsoid", "frustum", "sphere")
    BOX_FIELD_NUMBER: _ClassVar[int]
    CAPSULE_FIELD_NUMBER: _ClassVar[int]
    CYLINDER_FIELD_NUMBER: _ClassVar[int]
    ELLIPSOID_FIELD_NUMBER: _ClassVar[int]
    FRUSTUM_FIELD_NUMBER: _ClassVar[int]
    SPHERE_FIELD_NUMBER: _ClassVar[int]
    box: _primitives_pb2.Box
    capsule: _primitives_pb2.Capsule
    cylinder: _primitives_pb2.Cylinder
    ellipsoid: _primitives_pb2.Ellipsoid
    frustum: _primitives_pb2.Frustum
    sphere: _primitives_pb2.Sphere
    def __init__(self, box: _Optional[_Union[_primitives_pb2.Box, _Mapping]] = ..., capsule: _Optional[_Union[_primitives_pb2.Capsule, _Mapping]] = ..., cylinder: _Optional[_Union[_primitives_pb2.Cylinder, _Mapping]] = ..., ellipsoid: _Optional[_Union[_primitives_pb2.Ellipsoid, _Mapping]] = ..., frustum: _Optional[_Union[_primitives_pb2.Frustum, _Mapping]] = ..., sphere: _Optional[_Union[_primitives_pb2.Sphere, _Mapping]] = ...) -> None: ...
