from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class Renderable(_message.Message):
    __slots__ = ("glb_bytes",)
    GLB_BYTES_FIELD_NUMBER: _ClassVar[int]
    glb_bytes: bytes
    def __init__(self, glb_bytes: _Optional[bytes] = ...) -> None: ...
