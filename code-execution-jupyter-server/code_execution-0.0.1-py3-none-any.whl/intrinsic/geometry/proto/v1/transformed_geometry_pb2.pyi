from intrinsic.geometry.proto.v1 import geometric_transform_pb2 as _geometric_transform_pb2
from intrinsic.geometry.proto.v1 import geometry_pb2 as _geometry_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TransformedGeometry(_message.Message):
    __slots__ = ("geometry", "ref_t_shape")
    GEOMETRY_FIELD_NUMBER: _ClassVar[int]
    REF_T_SHAPE_FIELD_NUMBER: _ClassVar[int]
    geometry: _geometry_pb2.Geometry
    ref_t_shape: _geometric_transform_pb2.GeometricTransform
    def __init__(self, geometry: _Optional[_Union[_geometry_pb2.Geometry, _Mapping]] = ..., ref_t_shape: _Optional[_Union[_geometric_transform_pb2.GeometricTransform, _Mapping]] = ...) -> None: ...
