from intrinsic.geometry.proto.v1 import transformed_primitive_shape_pb2 as _transformed_primitive_shape_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TransformedPrimitiveShapeSet(_message.Message):
    __slots__ = ("primitives",)
    PRIMITIVES_FIELD_NUMBER: _ClassVar[int]
    primitives: _containers.RepeatedCompositeFieldContainer[_transformed_primitive_shape_pb2.TransformedPrimitiveShape]
    def __init__(self, primitives: _Optional[_Iterable[_Union[_transformed_primitive_shape_pb2.TransformedPrimitiveShape, _Mapping]]] = ...) -> None: ...
