from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class GPIOServiceTarget(_message.Message):
    __slots__ = ("gpio_service_grpc_target",)
    GPIO_SERVICE_GRPC_TARGET_FIELD_NUMBER: _ClassVar[int]
    gpio_service_grpc_target: str
    def __init__(self, gpio_service_grpc_target: _Optional[str] = ...) -> None: ...
