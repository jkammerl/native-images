from intrinsic.icon.proto import cart_space_pb2 as _cart_space_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ForceControlSettings(_message.Message):
    __slots__ = ("excessive_force_threshold", "excessive_torque_threshold", "virtual_translational_inertia", "virtual_rotational_inertia", "sensed_wrench_deadband")
    EXCESSIVE_FORCE_THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    EXCESSIVE_TORQUE_THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    VIRTUAL_TRANSLATIONAL_INERTIA_FIELD_NUMBER: _ClassVar[int]
    VIRTUAL_ROTATIONAL_INERTIA_FIELD_NUMBER: _ClassVar[int]
    SENSED_WRENCH_DEADBAND_FIELD_NUMBER: _ClassVar[int]
    excessive_force_threshold: float
    excessive_torque_threshold: float
    virtual_translational_inertia: float
    virtual_rotational_inertia: float
    sensed_wrench_deadband: _cart_space_pb2.Wrench
    def __init__(self, excessive_force_threshold: _Optional[float] = ..., excessive_torque_threshold: _Optional[float] = ..., virtual_translational_inertia: _Optional[float] = ..., virtual_rotational_inertia: _Optional[float] = ..., sensed_wrench_deadband: _Optional[_Union[_cart_space_pb2.Wrench, _Mapping]] = ...) -> None: ...
