from intrinsic.hardware.gpio import gpio_service_equipment_pb2 as _gpio_service_equipment_pb2
from intrinsic.icon.equipment import force_control_settings_pb2 as _force_control_settings_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Icon2PositionPart(_message.Message):
    __slots__ = ("part_name", "world_robot_collection_name", "object_names")
    class ObjectNamesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    PART_NAME_FIELD_NUMBER: _ClassVar[int]
    WORLD_ROBOT_COLLECTION_NAME_FIELD_NUMBER: _ClassVar[int]
    OBJECT_NAMES_FIELD_NUMBER: _ClassVar[int]
    part_name: str
    world_robot_collection_name: str
    object_names: _containers.ScalarMap[str, str]
    def __init__(self, part_name: _Optional[str] = ..., world_robot_collection_name: _Optional[str] = ..., object_names: _Optional[_Mapping[str, str]] = ...) -> None: ...

class Icon2GripperPart(_message.Message):
    __slots__ = ("part_name", "part_names")
    PART_NAME_FIELD_NUMBER: _ClassVar[int]
    PART_NAMES_FIELD_NUMBER: _ClassVar[int]
    part_name: str
    part_names: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, part_name: _Optional[str] = ..., part_names: _Optional[_Iterable[str]] = ...) -> None: ...

class Icon2AdioPart(_message.Message):
    __slots__ = ("icon_target", "gpio_service_target", "icon_parts")
    class IconTarget(_message.Message):
        __slots__ = ("part_name",)
        PART_NAME_FIELD_NUMBER: _ClassVar[int]
        part_name: str
        def __init__(self, part_name: _Optional[str] = ...) -> None: ...
    ICON_TARGET_FIELD_NUMBER: _ClassVar[int]
    GPIO_SERVICE_TARGET_FIELD_NUMBER: _ClassVar[int]
    ICON_PARTS_FIELD_NUMBER: _ClassVar[int]
    icon_target: Icon2AdioPart.IconTarget
    gpio_service_target: _gpio_service_equipment_pb2.GPIOServiceTarget
    icon_parts: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, icon_target: _Optional[_Union[Icon2AdioPart.IconTarget, _Mapping]] = ..., gpio_service_target: _Optional[_Union[_gpio_service_equipment_pb2.GPIOServiceTarget, _Mapping]] = ..., icon_parts: _Optional[_Iterable[str]] = ...) -> None: ...

class Icon2ForceTorqueSensorPart(_message.Message):
    __slots__ = ("part_name", "force_control_settings", "settings")
    class SettingsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _force_control_settings_pb2.ForceControlSettings
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_force_control_settings_pb2.ForceControlSettings, _Mapping]] = ...) -> None: ...
    PART_NAME_FIELD_NUMBER: _ClassVar[int]
    FORCE_CONTROL_SETTINGS_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_FIELD_NUMBER: _ClassVar[int]
    part_name: str
    force_control_settings: _force_control_settings_pb2.ForceControlSettings
    settings: _containers.MessageMap[str, _force_control_settings_pb2.ForceControlSettings]
    def __init__(self, part_name: _Optional[str] = ..., force_control_settings: _Optional[_Union[_force_control_settings_pb2.ForceControlSettings, _Mapping]] = ..., settings: _Optional[_Mapping[str, _force_control_settings_pb2.ForceControlSettings]] = ...) -> None: ...

class Icon2RangefinderPart(_message.Message):
    __slots__ = ("part_name", "part_names")
    PART_NAME_FIELD_NUMBER: _ClassVar[int]
    PART_NAMES_FIELD_NUMBER: _ClassVar[int]
    part_name: str
    part_names: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, part_name: _Optional[str] = ..., part_names: _Optional[_Iterable[str]] = ...) -> None: ...
