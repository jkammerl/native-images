from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CartState(_message.Message):
    __slots__ = ("timepoint_nsec", "pose", "velocity", "acceleration")
    TIMEPOINT_NSEC_FIELD_NUMBER: _ClassVar[int]
    POSE_FIELD_NUMBER: _ClassVar[int]
    VELOCITY_FIELD_NUMBER: _ClassVar[int]
    ACCELERATION_FIELD_NUMBER: _ClassVar[int]
    timepoint_nsec: int
    pose: _containers.RepeatedScalarFieldContainer[float]
    velocity: _containers.RepeatedScalarFieldContainer[float]
    acceleration: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, timepoint_nsec: _Optional[int] = ..., pose: _Optional[_Iterable[float]] = ..., velocity: _Optional[_Iterable[float]] = ..., acceleration: _Optional[_Iterable[float]] = ...) -> None: ...

class CartesianLimits(_message.Message):
    __slots__ = ("min_translational_position", "max_translational_position", "min_translational_velocity", "max_translational_velocity", "min_translational_acceleration", "max_translational_acceleration", "min_translational_jerk", "max_translational_jerk", "max_rotational_velocity", "max_rotational_acceleration", "max_rotational_jerk")
    MIN_TRANSLATIONAL_POSITION_FIELD_NUMBER: _ClassVar[int]
    MAX_TRANSLATIONAL_POSITION_FIELD_NUMBER: _ClassVar[int]
    MIN_TRANSLATIONAL_VELOCITY_FIELD_NUMBER: _ClassVar[int]
    MAX_TRANSLATIONAL_VELOCITY_FIELD_NUMBER: _ClassVar[int]
    MIN_TRANSLATIONAL_ACCELERATION_FIELD_NUMBER: _ClassVar[int]
    MAX_TRANSLATIONAL_ACCELERATION_FIELD_NUMBER: _ClassVar[int]
    MIN_TRANSLATIONAL_JERK_FIELD_NUMBER: _ClassVar[int]
    MAX_TRANSLATIONAL_JERK_FIELD_NUMBER: _ClassVar[int]
    MAX_ROTATIONAL_VELOCITY_FIELD_NUMBER: _ClassVar[int]
    MAX_ROTATIONAL_ACCELERATION_FIELD_NUMBER: _ClassVar[int]
    MAX_ROTATIONAL_JERK_FIELD_NUMBER: _ClassVar[int]
    min_translational_position: _containers.RepeatedScalarFieldContainer[float]
    max_translational_position: _containers.RepeatedScalarFieldContainer[float]
    min_translational_velocity: _containers.RepeatedScalarFieldContainer[float]
    max_translational_velocity: _containers.RepeatedScalarFieldContainer[float]
    min_translational_acceleration: _containers.RepeatedScalarFieldContainer[float]
    max_translational_acceleration: _containers.RepeatedScalarFieldContainer[float]
    min_translational_jerk: _containers.RepeatedScalarFieldContainer[float]
    max_translational_jerk: _containers.RepeatedScalarFieldContainer[float]
    max_rotational_velocity: float
    max_rotational_acceleration: float
    max_rotational_jerk: float
    def __init__(self, min_translational_position: _Optional[_Iterable[float]] = ..., max_translational_position: _Optional[_Iterable[float]] = ..., min_translational_velocity: _Optional[_Iterable[float]] = ..., max_translational_velocity: _Optional[_Iterable[float]] = ..., min_translational_acceleration: _Optional[_Iterable[float]] = ..., max_translational_acceleration: _Optional[_Iterable[float]] = ..., min_translational_jerk: _Optional[_Iterable[float]] = ..., max_translational_jerk: _Optional[_Iterable[float]] = ..., max_rotational_velocity: _Optional[float] = ..., max_rotational_acceleration: _Optional[float] = ..., max_rotational_jerk: _Optional[float] = ...) -> None: ...

class Point(_message.Message):
    __slots__ = ("x", "y", "z")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    Z_FIELD_NUMBER: _ClassVar[int]
    x: float
    y: float
    z: float
    def __init__(self, x: _Optional[float] = ..., y: _Optional[float] = ..., z: _Optional[float] = ...) -> None: ...

class Rotation(_message.Message):
    __slots__ = ("qx", "qy", "qz", "qw")
    QX_FIELD_NUMBER: _ClassVar[int]
    QY_FIELD_NUMBER: _ClassVar[int]
    QZ_FIELD_NUMBER: _ClassVar[int]
    QW_FIELD_NUMBER: _ClassVar[int]
    qx: float
    qy: float
    qz: float
    qw: float
    def __init__(self, qx: _Optional[float] = ..., qy: _Optional[float] = ..., qz: _Optional[float] = ..., qw: _Optional[float] = ...) -> None: ...

class Twist(_message.Message):
    __slots__ = ("x", "y", "z", "rx", "ry", "rz")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    Z_FIELD_NUMBER: _ClassVar[int]
    RX_FIELD_NUMBER: _ClassVar[int]
    RY_FIELD_NUMBER: _ClassVar[int]
    RZ_FIELD_NUMBER: _ClassVar[int]
    x: float
    y: float
    z: float
    rx: float
    ry: float
    rz: float
    def __init__(self, x: _Optional[float] = ..., y: _Optional[float] = ..., z: _Optional[float] = ..., rx: _Optional[float] = ..., ry: _Optional[float] = ..., rz: _Optional[float] = ...) -> None: ...

class Acceleration(_message.Message):
    __slots__ = ("x", "y", "z", "rx", "ry", "rz")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    Z_FIELD_NUMBER: _ClassVar[int]
    RX_FIELD_NUMBER: _ClassVar[int]
    RY_FIELD_NUMBER: _ClassVar[int]
    RZ_FIELD_NUMBER: _ClassVar[int]
    x: float
    y: float
    z: float
    rx: float
    ry: float
    rz: float
    def __init__(self, x: _Optional[float] = ..., y: _Optional[float] = ..., z: _Optional[float] = ..., rx: _Optional[float] = ..., ry: _Optional[float] = ..., rz: _Optional[float] = ...) -> None: ...

class Wrench(_message.Message):
    __slots__ = ("x", "y", "z", "rx", "ry", "rz")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    Z_FIELD_NUMBER: _ClassVar[int]
    RX_FIELD_NUMBER: _ClassVar[int]
    RY_FIELD_NUMBER: _ClassVar[int]
    RZ_FIELD_NUMBER: _ClassVar[int]
    x: float
    y: float
    z: float
    rx: float
    ry: float
    rz: float
    def __init__(self, x: _Optional[float] = ..., y: _Optional[float] = ..., z: _Optional[float] = ..., rx: _Optional[float] = ..., ry: _Optional[float] = ..., rz: _Optional[float] = ...) -> None: ...

class CartVec6(_message.Message):
    __slots__ = ("x", "y", "z", "rx", "ry", "rz")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    Z_FIELD_NUMBER: _ClassVar[int]
    RX_FIELD_NUMBER: _ClassVar[int]
    RY_FIELD_NUMBER: _ClassVar[int]
    RZ_FIELD_NUMBER: _ClassVar[int]
    x: float
    y: float
    z: float
    rx: float
    ry: float
    rz: float
    def __init__(self, x: _Optional[float] = ..., y: _Optional[float] = ..., z: _Optional[float] = ..., rx: _Optional[float] = ..., ry: _Optional[float] = ..., rz: _Optional[float] = ...) -> None: ...

class CartVec6b(_message.Message):
    __slots__ = ("x", "y", "z", "rx", "ry", "rz")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    Z_FIELD_NUMBER: _ClassVar[int]
    RX_FIELD_NUMBER: _ClassVar[int]
    RY_FIELD_NUMBER: _ClassVar[int]
    RZ_FIELD_NUMBER: _ClassVar[int]
    x: bool
    y: bool
    z: bool
    rx: bool
    ry: bool
    rz: bool
    def __init__(self, x: _Optional[bool] = ..., y: _Optional[bool] = ..., z: _Optional[bool] = ..., rx: _Optional[bool] = ..., ry: _Optional[bool] = ..., rz: _Optional[bool] = ...) -> None: ...

class Transform(_message.Message):
    __slots__ = ("pos", "rot")
    POS_FIELD_NUMBER: _ClassVar[int]
    ROT_FIELD_NUMBER: _ClassVar[int]
    pos: Point
    rot: Rotation
    def __init__(self, pos: _Optional[_Union[Point, _Mapping]] = ..., rot: _Optional[_Union[Rotation, _Mapping]] = ...) -> None: ...
