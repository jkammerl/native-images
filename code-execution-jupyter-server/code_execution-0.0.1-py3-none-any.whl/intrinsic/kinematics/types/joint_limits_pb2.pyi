from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RepeatedDouble(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, values: _Optional[_Iterable[float]] = ...) -> None: ...

class JointLimits(_message.Message):
    __slots__ = ("min_position", "max_position", "max_velocity", "max_acceleration", "max_jerk", "max_effort")
    MIN_POSITION_FIELD_NUMBER: _ClassVar[int]
    MAX_POSITION_FIELD_NUMBER: _ClassVar[int]
    MAX_VELOCITY_FIELD_NUMBER: _ClassVar[int]
    MAX_ACCELERATION_FIELD_NUMBER: _ClassVar[int]
    MAX_JERK_FIELD_NUMBER: _ClassVar[int]
    MAX_EFFORT_FIELD_NUMBER: _ClassVar[int]
    min_position: RepeatedDouble
    max_position: RepeatedDouble
    max_velocity: RepeatedDouble
    max_acceleration: RepeatedDouble
    max_jerk: RepeatedDouble
    max_effort: RepeatedDouble
    def __init__(self, min_position: _Optional[_Union[RepeatedDouble, _Mapping]] = ..., max_position: _Optional[_Union[RepeatedDouble, _Mapping]] = ..., max_velocity: _Optional[_Union[RepeatedDouble, _Mapping]] = ..., max_acceleration: _Optional[_Union[RepeatedDouble, _Mapping]] = ..., max_jerk: _Optional[_Union[RepeatedDouble, _Mapping]] = ..., max_effort: _Optional[_Union[RepeatedDouble, _Mapping]] = ...) -> None: ...

class JointLimitsUpdate(_message.Message):
    __slots__ = ("min_position", "max_position", "max_velocity", "max_acceleration", "max_jerk", "max_effort")
    MIN_POSITION_FIELD_NUMBER: _ClassVar[int]
    MAX_POSITION_FIELD_NUMBER: _ClassVar[int]
    MAX_VELOCITY_FIELD_NUMBER: _ClassVar[int]
    MAX_ACCELERATION_FIELD_NUMBER: _ClassVar[int]
    MAX_JERK_FIELD_NUMBER: _ClassVar[int]
    MAX_EFFORT_FIELD_NUMBER: _ClassVar[int]
    min_position: RepeatedDouble
    max_position: RepeatedDouble
    max_velocity: RepeatedDouble
    max_acceleration: RepeatedDouble
    max_jerk: RepeatedDouble
    max_effort: RepeatedDouble
    def __init__(self, min_position: _Optional[_Union[RepeatedDouble, _Mapping]] = ..., max_position: _Optional[_Union[RepeatedDouble, _Mapping]] = ..., max_velocity: _Optional[_Union[RepeatedDouble, _Mapping]] = ..., max_acceleration: _Optional[_Union[RepeatedDouble, _Mapping]] = ..., max_jerk: _Optional[_Union[RepeatedDouble, _Mapping]] = ..., max_effort: _Optional[_Union[RepeatedDouble, _Mapping]] = ...) -> None: ...

class JointLimitUpdate(_message.Message):
    __slots__ = ("min_position", "max_position", "max_velocity", "max_acceleration", "max_jerk", "max_effort")
    MIN_POSITION_FIELD_NUMBER: _ClassVar[int]
    MAX_POSITION_FIELD_NUMBER: _ClassVar[int]
    MAX_VELOCITY_FIELD_NUMBER: _ClassVar[int]
    MAX_ACCELERATION_FIELD_NUMBER: _ClassVar[int]
    MAX_JERK_FIELD_NUMBER: _ClassVar[int]
    MAX_EFFORT_FIELD_NUMBER: _ClassVar[int]
    min_position: float
    max_position: float
    max_velocity: float
    max_acceleration: float
    max_jerk: float
    max_effort: float
    def __init__(self, min_position: _Optional[float] = ..., max_position: _Optional[float] = ..., max_velocity: _Optional[float] = ..., max_acceleration: _Optional[float] = ..., max_jerk: _Optional[float] = ..., max_effort: _Optional[float] = ...) -> None: ...
