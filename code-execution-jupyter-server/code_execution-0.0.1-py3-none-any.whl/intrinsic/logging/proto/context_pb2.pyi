from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class Context(_message.Message):
    __slots__ = ("scene_id", "executive_session_id", "executive_plan_id", "executive_plan_action_id", "skill_id", "parent_skill_id", "icon_session_id", "icon_action_id", "visualization_context_id", "labels")
    class LabelsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    SCENE_ID_FIELD_NUMBER: _ClassVar[int]
    EXECUTIVE_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    EXECUTIVE_PLAN_ID_FIELD_NUMBER: _ClassVar[int]
    EXECUTIVE_PLAN_ACTION_ID_FIELD_NUMBER: _ClassVar[int]
    SKILL_ID_FIELD_NUMBER: _ClassVar[int]
    PARENT_SKILL_ID_FIELD_NUMBER: _ClassVar[int]
    ICON_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    ICON_ACTION_ID_FIELD_NUMBER: _ClassVar[int]
    VISUALIZATION_CONTEXT_ID_FIELD_NUMBER: _ClassVar[int]
    LABELS_FIELD_NUMBER: _ClassVar[int]
    scene_id: str
    executive_session_id: int
    executive_plan_id: int
    executive_plan_action_id: int
    skill_id: int
    parent_skill_id: int
    icon_session_id: int
    icon_action_id: int
    visualization_context_id: int
    labels: _containers.ScalarMap[str, str]
    def __init__(self, scene_id: _Optional[str] = ..., executive_session_id: _Optional[int] = ..., executive_plan_id: _Optional[int] = ..., executive_plan_action_id: _Optional[int] = ..., skill_id: _Optional[int] = ..., parent_skill_id: _Optional[int] = ..., icon_session_id: _Optional[int] = ..., icon_action_id: _Optional[int] = ..., visualization_context_id: _Optional[int] = ..., labels: _Optional[_Mapping[str, str]] = ...) -> None: ...
