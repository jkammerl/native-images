from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Array(_message.Message):
    __slots__ = ("data", "shape", "type", "byte_order")
    class ScalarType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        UNSPECIFIED_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        BOOL_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        INT8_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        INT16_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        INT32_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        INT64_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        UINT8_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        UINT16_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        UINT32_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        UINT64_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        FLOAT16_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        FLOAT32_SCALAR_TYPE: _ClassVar[Array.ScalarType]
        FLOAT64_SCALAR_TYPE: _ClassVar[Array.ScalarType]
    UNSPECIFIED_SCALAR_TYPE: Array.ScalarType
    BOOL_SCALAR_TYPE: Array.ScalarType
    INT8_SCALAR_TYPE: Array.ScalarType
    INT16_SCALAR_TYPE: Array.ScalarType
    INT32_SCALAR_TYPE: Array.ScalarType
    INT64_SCALAR_TYPE: Array.ScalarType
    UINT8_SCALAR_TYPE: Array.ScalarType
    UINT16_SCALAR_TYPE: Array.ScalarType
    UINT32_SCALAR_TYPE: Array.ScalarType
    UINT64_SCALAR_TYPE: Array.ScalarType
    FLOAT16_SCALAR_TYPE: Array.ScalarType
    FLOAT32_SCALAR_TYPE: Array.ScalarType
    FLOAT64_SCALAR_TYPE: Array.ScalarType
    class ByteOrder(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        UNSPECIFIED_BYTE_ORDER: _ClassVar[Array.ByteOrder]
        NO_BYTE_ORDER: _ClassVar[Array.ByteOrder]
        LITTLE_ENDIAN_BYTE_ORDER: _ClassVar[Array.ByteOrder]
        BIG_ENDIAN_BYTE_ORDER: _ClassVar[Array.ByteOrder]
    UNSPECIFIED_BYTE_ORDER: Array.ByteOrder
    NO_BYTE_ORDER: Array.ByteOrder
    LITTLE_ENDIAN_BYTE_ORDER: Array.ByteOrder
    BIG_ENDIAN_BYTE_ORDER: Array.ByteOrder
    DATA_FIELD_NUMBER: _ClassVar[int]
    SHAPE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    BYTE_ORDER_FIELD_NUMBER: _ClassVar[int]
    data: bytes
    shape: _containers.RepeatedScalarFieldContainer[int]
    type: Array.ScalarType
    byte_order: Array.ByteOrder
    def __init__(self, data: _Optional[bytes] = ..., shape: _Optional[_Iterable[int]] = ..., type: _Optional[_Union[Array.ScalarType, str]] = ..., byte_order: _Optional[_Union[Array.ByteOrder, str]] = ...) -> None: ...
