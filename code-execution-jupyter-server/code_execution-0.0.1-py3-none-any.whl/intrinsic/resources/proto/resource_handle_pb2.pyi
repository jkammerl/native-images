from google.protobuf import any_pb2 as _any_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ResourceHandle(_message.Message):
    __slots__ = ("name", "resource_data", "connection_info")
    class ResourceData(_message.Message):
        __slots__ = ("contents",)
        CONTENTS_FIELD_NUMBER: _ClassVar[int]
        contents: _any_pb2.Any
        def __init__(self, contents: _Optional[_Union[_any_pb2.Any, _Mapping]] = ...) -> None: ...
    class ResourceDataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: ResourceHandle.ResourceData
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[ResourceHandle.ResourceData, _Mapping]] = ...) -> None: ...
    NAME_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_DATA_FIELD_NUMBER: _ClassVar[int]
    CONNECTION_INFO_FIELD_NUMBER: _ClassVar[int]
    name: str
    resource_data: _containers.MessageMap[str, ResourceHandle.ResourceData]
    connection_info: ResourceConnectionInfo
    def __init__(self, name: _Optional[str] = ..., resource_data: _Optional[_Mapping[str, ResourceHandle.ResourceData]] = ..., connection_info: _Optional[_Union[ResourceConnectionInfo, _Mapping]] = ...) -> None: ...

class ResourceHandles(_message.Message):
    __slots__ = ("handles",)
    HANDLES_FIELD_NUMBER: _ClassVar[int]
    handles: _containers.RepeatedCompositeFieldContainer[ResourceHandle]
    def __init__(self, handles: _Optional[_Iterable[_Union[ResourceHandle, _Mapping]]] = ...) -> None: ...

class ResourceConnectionInfo(_message.Message):
    __slots__ = ("grpc",)
    GRPC_FIELD_NUMBER: _ClassVar[int]
    grpc: ResourceGrpcConnectionInfo
    def __init__(self, grpc: _Optional[_Union[ResourceGrpcConnectionInfo, _Mapping]] = ...) -> None: ...

class ResourceGrpcConnectionInfo(_message.Message):
    __slots__ = ("address", "server_instance", "header")
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    SERVER_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    HEADER_FIELD_NUMBER: _ClassVar[int]
    address: str
    server_instance: str
    header: str
    def __init__(self, address: _Optional[str] = ..., server_instance: _Optional[str] = ..., header: _Optional[str] = ...) -> None: ...
