from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CollisionEntityPair(_message.Message):
    __slots__ = ("left_entity", "right_entity")
    class Entity(_message.Message):
        __slots__ = ("entity_name",)
        ENTITY_NAME_FIELD_NUMBER: _ClassVar[int]
        entity_name: str
        def __init__(self, entity_name: _Optional[str] = ...) -> None: ...
    LEFT_ENTITY_FIELD_NUMBER: _ClassVar[int]
    RIGHT_ENTITY_FIELD_NUMBER: _ClassVar[int]
    left_entity: CollisionEntityPair.Entity
    right_entity: CollisionEntityPair.Entity
    def __init__(self, left_entity: _Optional[_Union[CollisionEntityPair.Entity, _Mapping]] = ..., right_entity: _Optional[_Union[CollisionEntityPair.Entity, _Mapping]] = ...) -> None: ...

class CollisionMarginRule(_message.Message):
    __slots__ = ("entity_pair", "hard_margin")
    ENTITY_PAIR_FIELD_NUMBER: _ClassVar[int]
    HARD_MARGIN_FIELD_NUMBER: _ClassVar[int]
    entity_pair: CollisionEntityPair
    hard_margin: float
    def __init__(self, entity_pair: _Optional[_Union[CollisionEntityPair, _Mapping]] = ..., hard_margin: _Optional[float] = ...) -> None: ...

class CollisionExclusionRule(_message.Message):
    __slots__ = ("entity_pair", "is_excluded")
    ENTITY_PAIR_FIELD_NUMBER: _ClassVar[int]
    IS_EXCLUDED_FIELD_NUMBER: _ClassVar[int]
    entity_pair: CollisionEntityPair
    is_excluded: bool
    def __init__(self, entity_pair: _Optional[_Union[CollisionEntityPair, _Mapping]] = ..., is_excluded: _Optional[bool] = ...) -> None: ...

class CollisionRules(_message.Message):
    __slots__ = ("margin_rules", "exclusion_rules")
    MARGIN_RULES_FIELD_NUMBER: _ClassVar[int]
    EXCLUSION_RULES_FIELD_NUMBER: _ClassVar[int]
    margin_rules: _containers.RepeatedCompositeFieldContainer[CollisionMarginRule]
    exclusion_rules: _containers.RepeatedCompositeFieldContainer[CollisionExclusionRule]
    def __init__(self, margin_rules: _Optional[_Iterable[_Union[CollisionMarginRule, _Mapping]]] = ..., exclusion_rules: _Optional[_Iterable[_Union[CollisionExclusionRule, _Mapping]]] = ...) -> None: ...
