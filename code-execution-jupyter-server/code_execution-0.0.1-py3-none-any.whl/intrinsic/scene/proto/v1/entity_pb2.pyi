from intrinsic.math.proto import pose_pb2 as _pose_pb2
from intrinsic.world.proto import geometry_component_pb2 as _geometry_component_pb2
from intrinsic.world.proto import kinematics_component_pb2 as _kinematics_component_pb2
from intrinsic.world.proto import physics_component_pb2 as _physics_component_pb2
from intrinsic.world.proto import sensor_component_pb2 as _sensor_component_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Frame(_message.Message):
    __slots__ = ("is_attachment_frame",)
    IS_ATTACHMENT_FRAME_FIELD_NUMBER: _ClassVar[int]
    is_attachment_frame: bool
    def __init__(self, is_attachment_frame: _Optional[bool] = ...) -> None: ...

class Link(_message.Message):
    __slots__ = ("geometry_component", "physics_component")
    GEOMETRY_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    PHYSICS_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    geometry_component: _geometry_component_pb2.GeometryComponent
    physics_component: _physics_component_pb2.PhysicsComponent
    def __init__(self, geometry_component: _Optional[_Union[_geometry_component_pb2.GeometryComponent, _Mapping]] = ..., physics_component: _Optional[_Union[_physics_component_pb2.PhysicsComponent, _Mapping]] = ...) -> None: ...

class Joint(_message.Message):
    __slots__ = ("kinematics_component",)
    KINEMATICS_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    kinematics_component: _kinematics_component_pb2.KinematicsComponent
    def __init__(self, kinematics_component: _Optional[_Union[_kinematics_component_pb2.KinematicsComponent, _Mapping]] = ...) -> None: ...

class Sensor(_message.Message):
    __slots__ = ("sensor_component",)
    SENSOR_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    sensor_component: _sensor_component_pb2.SensorComponent
    def __init__(self, sensor_component: _Optional[_Union[_sensor_component_pb2.SensorComponent, _Mapping]] = ...) -> None: ...

class Entity(_message.Message):
    __slots__ = ("name", "parent_name", "parent_t_this", "frame", "link", "joint", "sensor")
    NAME_FIELD_NUMBER: _ClassVar[int]
    PARENT_NAME_FIELD_NUMBER: _ClassVar[int]
    PARENT_T_THIS_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    LINK_FIELD_NUMBER: _ClassVar[int]
    JOINT_FIELD_NUMBER: _ClassVar[int]
    SENSOR_FIELD_NUMBER: _ClassVar[int]
    name: str
    parent_name: str
    parent_t_this: _pose_pb2.Pose
    frame: Frame
    link: Link
    joint: Joint
    sensor: Sensor
    def __init__(self, name: _Optional[str] = ..., parent_name: _Optional[str] = ..., parent_t_this: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., frame: _Optional[_Union[Frame, _Mapping]] = ..., link: _Optional[_Union[Link, _Mapping]] = ..., joint: _Optional[_Union[Joint, _Mapping]] = ..., sensor: _Optional[_Union[Sensor, _Mapping]] = ...) -> None: ...
