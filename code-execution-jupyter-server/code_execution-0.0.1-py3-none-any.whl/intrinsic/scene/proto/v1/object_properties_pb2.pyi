from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ObjectProperties(_message.Message):
    __slots__ = ("kinematics",)
    KINEMATICS_FIELD_NUMBER: _ClassVar[int]
    kinematics: Kinematics
    def __init__(self, kinematics: _Optional[_Union[Kinematics, _Mapping]] = ...) -> None: ...

class Kinematics(_message.Message):
    __slots__ = ("limits", "ik_solvers", "named_configurations")
    LIMITS_FIELD_NUMBER: _ClassVar[int]
    IK_SOLVERS_FIELD_NUMBER: _ClassVar[int]
    NAMED_CONFIGURATIONS_FIELD_NUMBER: _ClassVar[int]
    limits: CartesianLimits
    ik_solvers: _containers.RepeatedCompositeFieldContainer[IkSolver]
    named_configurations: _containers.RepeatedCompositeFieldContainer[NamedConfiguration]
    def __init__(self, limits: _Optional[_Union[CartesianLimits, _Mapping]] = ..., ik_solvers: _Optional[_Iterable[_Union[IkSolver, _Mapping]]] = ..., named_configurations: _Optional[_Iterable[_Union[NamedConfiguration, _Mapping]]] = ...) -> None: ...

class CartesianLimits(_message.Message):
    __slots__ = ("min_translational_velocity", "max_translational_velocity", "min_translational_acceleration", "max_translational_acceleration", "min_translational_jerk", "max_translational_jerk", "min_translational_position", "max_translational_position", "max_rotational_velocity", "max_rotational_acceleration", "max_rotational_jerk")
    MIN_TRANSLATIONAL_VELOCITY_FIELD_NUMBER: _ClassVar[int]
    MAX_TRANSLATIONAL_VELOCITY_FIELD_NUMBER: _ClassVar[int]
    MIN_TRANSLATIONAL_ACCELERATION_FIELD_NUMBER: _ClassVar[int]
    MAX_TRANSLATIONAL_ACCELERATION_FIELD_NUMBER: _ClassVar[int]
    MIN_TRANSLATIONAL_JERK_FIELD_NUMBER: _ClassVar[int]
    MAX_TRANSLATIONAL_JERK_FIELD_NUMBER: _ClassVar[int]
    MIN_TRANSLATIONAL_POSITION_FIELD_NUMBER: _ClassVar[int]
    MAX_TRANSLATIONAL_POSITION_FIELD_NUMBER: _ClassVar[int]
    MAX_ROTATIONAL_VELOCITY_FIELD_NUMBER: _ClassVar[int]
    MAX_ROTATIONAL_ACCELERATION_FIELD_NUMBER: _ClassVar[int]
    MAX_ROTATIONAL_JERK_FIELD_NUMBER: _ClassVar[int]
    min_translational_velocity: _containers.RepeatedScalarFieldContainer[float]
    max_translational_velocity: _containers.RepeatedScalarFieldContainer[float]
    min_translational_acceleration: _containers.RepeatedScalarFieldContainer[float]
    max_translational_acceleration: _containers.RepeatedScalarFieldContainer[float]
    min_translational_jerk: _containers.RepeatedScalarFieldContainer[float]
    max_translational_jerk: _containers.RepeatedScalarFieldContainer[float]
    min_translational_position: _containers.RepeatedScalarFieldContainer[float]
    max_translational_position: _containers.RepeatedScalarFieldContainer[float]
    max_rotational_velocity: float
    max_rotational_acceleration: float
    max_rotational_jerk: float
    def __init__(self, min_translational_velocity: _Optional[_Iterable[float]] = ..., max_translational_velocity: _Optional[_Iterable[float]] = ..., min_translational_acceleration: _Optional[_Iterable[float]] = ..., max_translational_acceleration: _Optional[_Iterable[float]] = ..., min_translational_jerk: _Optional[_Iterable[float]] = ..., max_translational_jerk: _Optional[_Iterable[float]] = ..., min_translational_position: _Optional[_Iterable[float]] = ..., max_translational_position: _Optional[_Iterable[float]] = ..., max_rotational_velocity: _Optional[float] = ..., max_rotational_acceleration: _Optional[float] = ..., max_rotational_jerk: _Optional[float] = ...) -> None: ...

class IkSolver(_message.Message):
    __slots__ = ("ik_solver", "tip_link_name")
    IK_SOLVER_FIELD_NUMBER: _ClassVar[int]
    TIP_LINK_NAME_FIELD_NUMBER: _ClassVar[int]
    ik_solver: str
    tip_link_name: str
    def __init__(self, ik_solver: _Optional[str] = ..., tip_link_name: _Optional[str] = ...) -> None: ...

class NamedConfiguration(_message.Message):
    __slots__ = ("name", "joint_positions")
    class JointPositionsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: float
        def __init__(self, key: _Optional[str] = ..., value: _Optional[float] = ...) -> None: ...
    NAME_FIELD_NUMBER: _ClassVar[int]
    JOINT_POSITIONS_FIELD_NUMBER: _ClassVar[int]
    name: str
    joint_positions: _containers.ScalarMap[str, float]
    def __init__(self, name: _Optional[str] = ..., joint_positions: _Optional[_Mapping[str, float]] = ...) -> None: ...
