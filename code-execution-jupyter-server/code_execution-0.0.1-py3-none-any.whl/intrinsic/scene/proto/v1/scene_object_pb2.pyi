from google.protobuf import any_pb2 as _any_pb2
from intrinsic.scene.proto.v1 import collision_rules_pb2 as _collision_rules_pb2
from intrinsic.scene.proto.v1 import entity_pb2 as _entity_pb2
from intrinsic.scene.proto.v1 import object_properties_pb2 as _object_properties_pb2
from intrinsic.scene.proto.v1 import simulation_spec_pb2 as _simulation_spec_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SceneObject(_message.Message):
    __slots__ = ("name", "properties", "entities", "simulation_spec", "collision_rules", "user_data")
    class UserDataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _any_pb2.Any
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_any_pb2.Any, _Mapping]] = ...) -> None: ...
    NAME_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    SIMULATION_SPEC_FIELD_NUMBER: _ClassVar[int]
    COLLISION_RULES_FIELD_NUMBER: _ClassVar[int]
    USER_DATA_FIELD_NUMBER: _ClassVar[int]
    name: str
    properties: _object_properties_pb2.ObjectProperties
    entities: _containers.RepeatedCompositeFieldContainer[_entity_pb2.Entity]
    simulation_spec: _simulation_spec_pb2.SimulationSpec
    collision_rules: _collision_rules_pb2.CollisionRules
    user_data: _containers.MessageMap[str, _any_pb2.Any]
    def __init__(self, name: _Optional[str] = ..., properties: _Optional[_Union[_object_properties_pb2.ObjectProperties, _Mapping]] = ..., entities: _Optional[_Iterable[_Union[_entity_pb2.Entity, _Mapping]]] = ..., simulation_spec: _Optional[_Union[_simulation_spec_pb2.SimulationSpec, _Mapping]] = ..., collision_rules: _Optional[_Union[_collision_rules_pb2.CollisionRules, _Mapping]] = ..., user_data: _Optional[_Mapping[str, _any_pb2.Any]] = ...) -> None: ...
