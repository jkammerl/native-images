from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SimulationSpec(_message.Message):
    __slots__ = ("robot", "is_static", "multi_camera_plugin", "extra_inlined_plugins", "disabled")
    ROBOT_FIELD_NUMBER: _ClassVar[int]
    IS_STATIC_FIELD_NUMBER: _ClassVar[int]
    MULTI_CAMERA_PLUGIN_FIELD_NUMBER: _ClassVar[int]
    EXTRA_INLINED_PLUGINS_FIELD_NUMBER: _ClassVar[int]
    DISABLED_FIELD_NUMBER: _ClassVar[int]
    robot: RobotSimPluginSpec
    is_static: bool
    multi_camera_plugin: MultiCameraPluginSpec
    extra_inlined_plugins: _containers.RepeatedScalarFieldContainer[str]
    disabled: bool
    def __init__(self, robot: _Optional[_Union[RobotSimPluginSpec, _Mapping]] = ..., is_static: _Optional[bool] = ..., multi_camera_plugin: _Optional[_Union[MultiCameraPluginSpec, _Mapping]] = ..., extra_inlined_plugins: _Optional[_Iterable[str]] = ..., disabled: _Optional[bool] = ...) -> None: ...

class MultiCameraPluginSpec(_message.Message):
    __slots__ = ("sensors", "device_id")
    class Sensor(_message.Message):
        __slots__ = ("id", "name", "image_type")
        ID_FIELD_NUMBER: _ClassVar[int]
        NAME_FIELD_NUMBER: _ClassVar[int]
        IMAGE_TYPE_FIELD_NUMBER: _ClassVar[int]
        id: int
        name: str
        image_type: str
        def __init__(self, id: _Optional[int] = ..., name: _Optional[str] = ..., image_type: _Optional[str] = ...) -> None: ...
    SENSORS_FIELD_NUMBER: _ClassVar[int]
    DEVICE_ID_FIELD_NUMBER: _ClassVar[int]
    sensors: _containers.RepeatedCompositeFieldContainer[MultiCameraPluginSpec.Sensor]
    device_id: str
    def __init__(self, sensors: _Optional[_Iterable[_Union[MultiCameraPluginSpec.Sensor, _Mapping]]] = ..., device_id: _Optional[str] = ...) -> None: ...

class RobotSimPluginSpec(_message.Message):
    __slots__ = ("icon_sim_spec", "device_specs")
    class IconSimSpec(_message.Message):
        __slots__ = ()
        def __init__(self) -> None: ...
    class DeviceSpec(_message.Message):
        __slots__ = ("name", "type", "joint_entity", "initial_state")
        NAME_FIELD_NUMBER: _ClassVar[int]
        TYPE_FIELD_NUMBER: _ClassVar[int]
        JOINT_ENTITY_FIELD_NUMBER: _ClassVar[int]
        INITIAL_STATE_FIELD_NUMBER: _ClassVar[int]
        name: str
        type: str
        joint_entity: str
        initial_state: float
        def __init__(self, name: _Optional[str] = ..., type: _Optional[str] = ..., joint_entity: _Optional[str] = ..., initial_state: _Optional[float] = ...) -> None: ...
    ICON_SIM_SPEC_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SPECS_FIELD_NUMBER: _ClassVar[int]
    icon_sim_spec: RobotSimPluginSpec.IconSimSpec
    device_specs: _containers.RepeatedCompositeFieldContainer[RobotSimPluginSpec.DeviceSpec]
    def __init__(self, icon_sim_spec: _Optional[_Union[RobotSimPluginSpec.IconSimSpec, _Mapping]] = ..., device_specs: _Optional[_Iterable[_Union[RobotSimPluginSpec.DeviceSpec, _Mapping]]] = ...) -> None: ...
