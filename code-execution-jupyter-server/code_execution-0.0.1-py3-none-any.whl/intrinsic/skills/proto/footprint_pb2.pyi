from intrinsic.geometry.proto import transformed_geometry_storage_refs_pb2 as _transformed_geometry_storage_refs_pb2
from intrinsic.world.proto import object_world_refs_pb2 as _object_world_refs_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Footprint(_message.Message):
    __slots__ = ("volume", "object_reservation", "resource_reservation", "lock_the_universe", "skip_missing_permissions")
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    OBJECT_RESERVATION_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_RESERVATION_FIELD_NUMBER: _ClassVar[int]
    LOCK_THE_UNIVERSE_FIELD_NUMBER: _ClassVar[int]
    SKIP_MISSING_PERMISSIONS_FIELD_NUMBER: _ClassVar[int]
    volume: _containers.RepeatedCompositeFieldContainer[VolumeReservation]
    object_reservation: _containers.RepeatedCompositeFieldContainer[ObjectWorldReservation]
    resource_reservation: _containers.RepeatedCompositeFieldContainer[ResourceReservation]
    lock_the_universe: bool
    skip_missing_permissions: bool
    def __init__(self, volume: _Optional[_Iterable[_Union[VolumeReservation, _Mapping]]] = ..., object_reservation: _Optional[_Iterable[_Union[ObjectWorldReservation, _Mapping]]] = ..., resource_reservation: _Optional[_Iterable[_Union[ResourceReservation, _Mapping]]] = ..., lock_the_universe: _Optional[bool] = ..., skip_missing_permissions: _Optional[bool] = ...) -> None: ...

class ObjectWorldReservation(_message.Message):
    __slots__ = ("type", "object", "frame")
    class SharingType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        WRITE: _ClassVar[ObjectWorldReservation.SharingType]
        READ: _ClassVar[ObjectWorldReservation.SharingType]
    WRITE: ObjectWorldReservation.SharingType
    READ: ObjectWorldReservation.SharingType
    TYPE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    type: ObjectWorldReservation.SharingType
    object: _object_world_refs_pb2.ObjectReferenceByName
    frame: _object_world_refs_pb2.FrameReferenceByName
    def __init__(self, type: _Optional[_Union[ObjectWorldReservation.SharingType, str]] = ..., object: _Optional[_Union[_object_world_refs_pb2.ObjectReferenceByName, _Mapping]] = ..., frame: _Optional[_Union[_object_world_refs_pb2.FrameReferenceByName, _Mapping]] = ...) -> None: ...

class VolumeReservation(_message.Message):
    __slots__ = ("type", "shape")
    class SharingType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        WRITE: _ClassVar[VolumeReservation.SharingType]
    WRITE: VolumeReservation.SharingType
    TYPE_FIELD_NUMBER: _ClassVar[int]
    SHAPE_FIELD_NUMBER: _ClassVar[int]
    type: VolumeReservation.SharingType
    shape: _transformed_geometry_storage_refs_pb2.TransformedGeometryStorageRefs
    def __init__(self, type: _Optional[_Union[VolumeReservation.SharingType, str]] = ..., shape: _Optional[_Union[_transformed_geometry_storage_refs_pb2.TransformedGeometryStorageRefs, _Mapping]] = ...) -> None: ...

class ResourceReservation(_message.Message):
    __slots__ = ("type", "name")
    class SharingType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        UNSPECIFIED: _ClassVar[ResourceReservation.SharingType]
        WRITE: _ClassVar[ResourceReservation.SharingType]
        READ: _ClassVar[ResourceReservation.SharingType]
        WRITE_EXCLUSIVE_READ_NONEXCLUSIVE: _ClassVar[ResourceReservation.SharingType]
        WRITE_NONEXCLUSIVE: _ClassVar[ResourceReservation.SharingType]
    UNSPECIFIED: ResourceReservation.SharingType
    WRITE: ResourceReservation.SharingType
    READ: ResourceReservation.SharingType
    WRITE_EXCLUSIVE_READ_NONEXCLUSIVE: ResourceReservation.SharingType
    WRITE_NONEXCLUSIVE: ResourceReservation.SharingType
    TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    type: ResourceReservation.SharingType
    name: str
    def __init__(self, type: _Optional[_Union[ResourceReservation.SharingType, str]] = ..., name: _Optional[str] = ...) -> None: ...
