from google.protobuf import descriptor_pb2 as _descriptor_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor
SKILL_PARAMETER_METADATA_FIELD_NUMBER: _ClassVar[int]
skill_parameter_metadata: _descriptor.FieldDescriptor

class SkillParameterMetadata(_message.Message):
    __slots__ = ("unit", "is_icon2_position_part")
    UNIT_FIELD_NUMBER: _ClassVar[int]
    IS_ICON2_POSITION_PART_FIELD_NUMBER: _ClassVar[int]
    unit: str
    is_icon2_position_part: bool
    def __init__(self, unit: _Optional[str] = ..., is_icon2_position_part: _Optional[bool] = ...) -> None: ...
