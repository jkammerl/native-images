import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from intrinsic.logging.proto import context_pb2 as _context_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StatusCode(_message.Message):
    __slots__ = ("component", "code")
    COMPONENT_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    component: str
    code: int
    def __init__(self, component: _Optional[str] = ..., code: _Optional[int] = ...) -> None: ...

class ExtendedStatus(_message.Message):
    __slots__ = ("status_code", "severity", "title", "timestamp", "context", "related_to", "user_report", "debug_report")
    class Severity(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        DEFAULT: _ClassVar[ExtendedStatus.Severity]
        INFO: _ClassVar[ExtendedStatus.Severity]
        WARNING: _ClassVar[ExtendedStatus.Severity]
        ERROR: _ClassVar[ExtendedStatus.Severity]
        FATAL: _ClassVar[ExtendedStatus.Severity]
    DEFAULT: ExtendedStatus.Severity
    INFO: ExtendedStatus.Severity
    WARNING: ExtendedStatus.Severity
    ERROR: ExtendedStatus.Severity
    FATAL: ExtendedStatus.Severity
    class Relations(_message.Message):
        __slots__ = ("behavior_tree_node", "log_context")
        class BehaviorTreeNodeReference(_message.Message):
            __slots__ = ("tree_id", "node_id")
            TREE_ID_FIELD_NUMBER: _ClassVar[int]
            NODE_ID_FIELD_NUMBER: _ClassVar[int]
            tree_id: str
            node_id: int
            def __init__(self, tree_id: _Optional[str] = ..., node_id: _Optional[int] = ...) -> None: ...
        BEHAVIOR_TREE_NODE_FIELD_NUMBER: _ClassVar[int]
        LOG_CONTEXT_FIELD_NUMBER: _ClassVar[int]
        behavior_tree_node: ExtendedStatus.Relations.BehaviorTreeNodeReference
        log_context: _context_pb2.Context
        def __init__(self, behavior_tree_node: _Optional[_Union[ExtendedStatus.Relations.BehaviorTreeNodeReference, _Mapping]] = ..., log_context: _Optional[_Union[_context_pb2.Context, _Mapping]] = ...) -> None: ...
    class UserReport(_message.Message):
        __slots__ = ("message", "instructions")
        MESSAGE_FIELD_NUMBER: _ClassVar[int]
        INSTRUCTIONS_FIELD_NUMBER: _ClassVar[int]
        message: str
        instructions: str
        def __init__(self, message: _Optional[str] = ..., instructions: _Optional[str] = ...) -> None: ...
    class DebugReport(_message.Message):
        __slots__ = ("message", "stack_trace")
        MESSAGE_FIELD_NUMBER: _ClassVar[int]
        STACK_TRACE_FIELD_NUMBER: _ClassVar[int]
        message: str
        stack_trace: str
        def __init__(self, message: _Optional[str] = ..., stack_trace: _Optional[str] = ...) -> None: ...
    STATUS_CODE_FIELD_NUMBER: _ClassVar[int]
    SEVERITY_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    RELATED_TO_FIELD_NUMBER: _ClassVar[int]
    USER_REPORT_FIELD_NUMBER: _ClassVar[int]
    DEBUG_REPORT_FIELD_NUMBER: _ClassVar[int]
    status_code: StatusCode
    severity: ExtendedStatus.Severity
    title: str
    timestamp: _timestamp_pb2.Timestamp
    context: _containers.RepeatedCompositeFieldContainer[ExtendedStatus]
    related_to: ExtendedStatus.Relations
    user_report: ExtendedStatus.UserReport
    debug_report: ExtendedStatus.DebugReport
    def __init__(self, status_code: _Optional[_Union[StatusCode, _Mapping]] = ..., severity: _Optional[_Union[ExtendedStatus.Severity, str]] = ..., title: _Optional[str] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., context: _Optional[_Iterable[_Union[ExtendedStatus, _Mapping]]] = ..., related_to: _Optional[_Union[ExtendedStatus.Relations, _Mapping]] = ..., user_report: _Optional[_Union[ExtendedStatus.UserReport, _Mapping]] = ..., debug_report: _Optional[_Union[ExtendedStatus.DebugReport, _Mapping]] = ...) -> None: ...
