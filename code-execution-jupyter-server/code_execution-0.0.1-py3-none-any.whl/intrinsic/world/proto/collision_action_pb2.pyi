from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CollisionMarginPair(_message.Message):
    __slots__ = ("hard_margin",)
    HARD_MARGIN_FIELD_NUMBER: _ClassVar[int]
    hard_margin: float
    def __init__(self, hard_margin: _Optional[float] = ...) -> None: ...

class CollisionAction(_message.Message):
    __slots__ = ("is_excluded", "margin")
    IS_EXCLUDED_FIELD_NUMBER: _ClassVar[int]
    MARGIN_FIELD_NUMBER: _ClassVar[int]
    is_excluded: bool
    margin: CollisionMarginPair
    def __init__(self, is_excluded: _Optional[bool] = ..., margin: _Optional[_Union[CollisionMarginPair, _Mapping]] = ...) -> None: ...
