from intrinsic.skills.proto import skill_parameter_metadata_pb2 as _skill_parameter_metadata_pb2
from intrinsic.world.proto import collision_action_pb2 as _collision_action_pb2
from intrinsic.world.proto import object_world_refs_pb2 as _object_world_refs_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ObjectOrEntityReference(_message.Message):
    __slots__ = ("object", "entity", "object_with_filter")
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    OBJECT_WITH_FILTER_FIELD_NUMBER: _ClassVar[int]
    object: _object_world_refs_pb2.ObjectReference
    entity: _object_world_refs_pb2.EntityReference
    object_with_filter: _object_world_refs_pb2.ObjectReferenceWithEntityFilter
    def __init__(self, object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., entity: _Optional[_Union[_object_world_refs_pb2.EntityReference, _Mapping]] = ..., object_with_filter: _Optional[_Union[_object_world_refs_pb2.ObjectReferenceWithEntityFilter, _Mapping]] = ...) -> None: ...

class CollisionSettings(_message.Message):
    __slots__ = ("disable_collision_checking", "minimum_margin", "collision_rules")
    class CollisionRule(_message.Message):
        __slots__ = ("collision_action", "left", "right")
        COLLISION_ACTION_FIELD_NUMBER: _ClassVar[int]
        LEFT_FIELD_NUMBER: _ClassVar[int]
        RIGHT_FIELD_NUMBER: _ClassVar[int]
        collision_action: _collision_action_pb2.CollisionAction
        left: _containers.RepeatedCompositeFieldContainer[ObjectOrEntityReference]
        right: _containers.RepeatedCompositeFieldContainer[ObjectOrEntityReference]
        def __init__(self, collision_action: _Optional[_Union[_collision_action_pb2.CollisionAction, _Mapping]] = ..., left: _Optional[_Iterable[_Union[ObjectOrEntityReference, _Mapping]]] = ..., right: _Optional[_Iterable[_Union[ObjectOrEntityReference, _Mapping]]] = ...) -> None: ...
    DISABLE_COLLISION_CHECKING_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_MARGIN_FIELD_NUMBER: _ClassVar[int]
    COLLISION_RULES_FIELD_NUMBER: _ClassVar[int]
    disable_collision_checking: bool
    minimum_margin: float
    collision_rules: _containers.RepeatedCompositeFieldContainer[CollisionSettings.CollisionRule]
    def __init__(self, disable_collision_checking: _Optional[bool] = ..., minimum_margin: _Optional[float] = ..., collision_rules: _Optional[_Iterable[_Union[CollisionSettings.CollisionRule, _Mapping]]] = ...) -> None: ...

class CollisionCheckingDebugInformation(_message.Message):
    __slots__ = ("collisions",)
    class Collision(_message.Message):
        __slots__ = ("left", "right", "desired_margin")
        LEFT_FIELD_NUMBER: _ClassVar[int]
        RIGHT_FIELD_NUMBER: _ClassVar[int]
        DESIRED_MARGIN_FIELD_NUMBER: _ClassVar[int]
        left: ObjectOrEntityReference
        right: _containers.RepeatedCompositeFieldContainer[ObjectOrEntityReference]
        desired_margin: float
        def __init__(self, left: _Optional[_Union[ObjectOrEntityReference, _Mapping]] = ..., right: _Optional[_Iterable[_Union[ObjectOrEntityReference, _Mapping]]] = ..., desired_margin: _Optional[float] = ...) -> None: ...
    COLLISIONS_FIELD_NUMBER: _ClassVar[int]
    collisions: _containers.RepeatedCompositeFieldContainer[CollisionCheckingDebugInformation.Collision]
    def __init__(self, collisions: _Optional[_Iterable[_Union[CollisionCheckingDebugInformation.Collision, _Mapping]]] = ...) -> None: ...
