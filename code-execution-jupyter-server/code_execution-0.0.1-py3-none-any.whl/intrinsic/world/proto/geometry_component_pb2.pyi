from intrinsic.geometry.proto import geometry_storage_refs_pb2 as _geometry_storage_refs_pb2
from intrinsic.geometry.proto.v1 import transformed_geometry_pb2 as _transformed_geometry_pb2
from intrinsic.math.proto import matrix_pb2 as _matrix_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GeometryOptions(_message.Message):
    __slots__ = ("fill_inside_for_distance_queries",)
    FILL_INSIDE_FOR_DISTANCE_QUERIES_FIELD_NUMBER: _ClassVar[int]
    fill_inside_for_distance_queries: bool
    def __init__(self, fill_inside_for_distance_queries: _Optional[bool] = ...) -> None: ...

class GeometryComponent(_message.Message):
    __slots__ = ("named_geometries",)
    class Geometry(_message.Message):
        __slots__ = ("geometry_storage_refs", "ref_t_shape_aff", "options")
        GEOMETRY_STORAGE_REFS_FIELD_NUMBER: _ClassVar[int]
        REF_T_SHAPE_AFF_FIELD_NUMBER: _ClassVar[int]
        OPTIONS_FIELD_NUMBER: _ClassVar[int]
        geometry_storage_refs: _geometry_storage_refs_pb2.GeometryStorageRefs
        ref_t_shape_aff: _matrix_pb2.Matrixd
        options: GeometryOptions
        def __init__(self, geometry_storage_refs: _Optional[_Union[_geometry_storage_refs_pb2.GeometryStorageRefs, _Mapping]] = ..., ref_t_shape_aff: _Optional[_Union[_matrix_pb2.Matrixd, _Mapping]] = ..., options: _Optional[_Union[GeometryOptions, _Mapping]] = ...) -> None: ...
    class GeometrySet(_message.Message):
        __slots__ = ("geometries", "named_geometries")
        class NamedGeometriesEntry(_message.Message):
            __slots__ = ("key", "value")
            KEY_FIELD_NUMBER: _ClassVar[int]
            VALUE_FIELD_NUMBER: _ClassVar[int]
            key: str
            value: _transformed_geometry_pb2.TransformedGeometry
            def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_transformed_geometry_pb2.TransformedGeometry, _Mapping]] = ...) -> None: ...
        GEOMETRIES_FIELD_NUMBER: _ClassVar[int]
        NAMED_GEOMETRIES_FIELD_NUMBER: _ClassVar[int]
        geometries: _containers.RepeatedCompositeFieldContainer[GeometryComponent.Geometry]
        named_geometries: _containers.MessageMap[str, _transformed_geometry_pb2.TransformedGeometry]
        def __init__(self, geometries: _Optional[_Iterable[_Union[GeometryComponent.Geometry, _Mapping]]] = ..., named_geometries: _Optional[_Mapping[str, _transformed_geometry_pb2.TransformedGeometry]] = ...) -> None: ...
    class NamedGeometriesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: GeometryComponent.GeometrySet
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[GeometryComponent.GeometrySet, _Mapping]] = ...) -> None: ...
    NAMED_GEOMETRIES_FIELD_NUMBER: _ClassVar[int]
    named_geometries: _containers.MessageMap[str, GeometryComponent.GeometrySet]
    def __init__(self, named_geometries: _Optional[_Mapping[str, GeometryComponent.GeometrySet]] = ...) -> None: ...
