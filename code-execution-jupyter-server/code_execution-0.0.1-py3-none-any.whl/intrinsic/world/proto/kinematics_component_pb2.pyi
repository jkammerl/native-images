from google.protobuf import timestamp_pb2 as _timestamp_pb2
from intrinsic.math.proto import pose_pb2 as _pose_pb2
from intrinsic.math.proto import vector3_pb2 as _vector3_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class KinematicsComponent(_message.Message):
    __slots__ = ("parent_t_inboard", "outboard_t_child", "motion_type", "axis", "raw_value", "system_limits", "application_limits", "damping", "friction")
    class MotionType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        MOTION_TYPE_UNDEFINED: _ClassVar[KinematicsComponent.MotionType]
        MOTION_TYPE_REVOLUTE: _ClassVar[KinematicsComponent.MotionType]
        MOTION_TYPE_PRISMATIC: _ClassVar[KinematicsComponent.MotionType]
        MOTION_TYPE_FIXED: _ClassVar[KinematicsComponent.MotionType]
    MOTION_TYPE_UNDEFINED: KinematicsComponent.MotionType
    MOTION_TYPE_REVOLUTE: KinematicsComponent.MotionType
    MOTION_TYPE_PRISMATIC: KinematicsComponent.MotionType
    MOTION_TYPE_FIXED: KinematicsComponent.MotionType
    class Limits(_message.Message):
        __slots__ = ("velocity", "acceleration", "jerk", "effort", "fixed_limits")
        class LimitPair(_message.Message):
            __slots__ = ("lower", "upper")
            LOWER_FIELD_NUMBER: _ClassVar[int]
            UPPER_FIELD_NUMBER: _ClassVar[int]
            lower: float
            upper: float
            def __init__(self, lower: _Optional[float] = ..., upper: _Optional[float] = ...) -> None: ...
        VELOCITY_FIELD_NUMBER: _ClassVar[int]
        ACCELERATION_FIELD_NUMBER: _ClassVar[int]
        JERK_FIELD_NUMBER: _ClassVar[int]
        EFFORT_FIELD_NUMBER: _ClassVar[int]
        FIXED_LIMITS_FIELD_NUMBER: _ClassVar[int]
        velocity: float
        acceleration: float
        jerk: float
        effort: float
        fixed_limits: KinematicsComponent.Limits.LimitPair
        def __init__(self, velocity: _Optional[float] = ..., acceleration: _Optional[float] = ..., jerk: _Optional[float] = ..., effort: _Optional[float] = ..., fixed_limits: _Optional[_Union[KinematicsComponent.Limits.LimitPair, _Mapping]] = ...) -> None: ...
    PARENT_T_INBOARD_FIELD_NUMBER: _ClassVar[int]
    OUTBOARD_T_CHILD_FIELD_NUMBER: _ClassVar[int]
    MOTION_TYPE_FIELD_NUMBER: _ClassVar[int]
    AXIS_FIELD_NUMBER: _ClassVar[int]
    RAW_VALUE_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_LIMITS_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_LIMITS_FIELD_NUMBER: _ClassVar[int]
    DAMPING_FIELD_NUMBER: _ClassVar[int]
    FRICTION_FIELD_NUMBER: _ClassVar[int]
    parent_t_inboard: _pose_pb2.Pose
    outboard_t_child: _pose_pb2.Pose
    motion_type: KinematicsComponent.MotionType
    axis: _vector3_pb2.Vector3
    raw_value: float
    system_limits: KinematicsComponent.Limits
    application_limits: KinematicsComponent.Limits
    damping: float
    friction: float
    def __init__(self, parent_t_inboard: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., outboard_t_child: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., motion_type: _Optional[_Union[KinematicsComponent.MotionType, str]] = ..., axis: _Optional[_Union[_vector3_pb2.Vector3, _Mapping]] = ..., raw_value: _Optional[float] = ..., system_limits: _Optional[_Union[KinematicsComponent.Limits, _Mapping]] = ..., application_limits: _Optional[_Union[KinematicsComponent.Limits, _Mapping]] = ..., damping: _Optional[float] = ..., friction: _Optional[float] = ...) -> None: ...
