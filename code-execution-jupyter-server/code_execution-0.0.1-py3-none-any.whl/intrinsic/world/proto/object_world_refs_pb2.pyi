from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ObjectReferenceByName(_message.Message):
    __slots__ = ("object_name",)
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    object_name: str
    def __init__(self, object_name: _Optional[str] = ...) -> None: ...

class FrameReferenceByName(_message.Message):
    __slots__ = ("object_name", "frame_name")
    OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    FRAME_NAME_FIELD_NUMBER: _ClassVar[int]
    object_name: str
    frame_name: str
    def __init__(self, object_name: _Optional[str] = ..., frame_name: _Optional[str] = ...) -> None: ...

class TransformNodeReferenceByName(_message.Message):
    __slots__ = ("object", "frame")
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    object: ObjectReferenceByName
    frame: FrameReferenceByName
    def __init__(self, object: _Optional[_Union[ObjectReferenceByName, _Mapping]] = ..., frame: _Optional[_Union[FrameReferenceByName, _Mapping]] = ...) -> None: ...

class ObjectReference(_message.Message):
    __slots__ = ("id", "by_name", "debug_hint")
    ID_FIELD_NUMBER: _ClassVar[int]
    BY_NAME_FIELD_NUMBER: _ClassVar[int]
    DEBUG_HINT_FIELD_NUMBER: _ClassVar[int]
    id: str
    by_name: ObjectReferenceByName
    debug_hint: str
    def __init__(self, id: _Optional[str] = ..., by_name: _Optional[_Union[ObjectReferenceByName, _Mapping]] = ..., debug_hint: _Optional[str] = ...) -> None: ...

class FrameReference(_message.Message):
    __slots__ = ("id", "by_name", "debug_hint")
    ID_FIELD_NUMBER: _ClassVar[int]
    BY_NAME_FIELD_NUMBER: _ClassVar[int]
    DEBUG_HINT_FIELD_NUMBER: _ClassVar[int]
    id: str
    by_name: FrameReferenceByName
    debug_hint: str
    def __init__(self, id: _Optional[str] = ..., by_name: _Optional[_Union[FrameReferenceByName, _Mapping]] = ..., debug_hint: _Optional[str] = ...) -> None: ...

class TransformNodeReference(_message.Message):
    __slots__ = ("id", "by_name", "debug_hint")
    ID_FIELD_NUMBER: _ClassVar[int]
    BY_NAME_FIELD_NUMBER: _ClassVar[int]
    DEBUG_HINT_FIELD_NUMBER: _ClassVar[int]
    id: str
    by_name: TransformNodeReferenceByName
    debug_hint: str
    def __init__(self, id: _Optional[str] = ..., by_name: _Optional[_Union[TransformNodeReferenceByName, _Mapping]] = ..., debug_hint: _Optional[str] = ...) -> None: ...

class EntityReference(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ObjectEntityFilter(_message.Message):
    __slots__ = ("include_base_entity", "include_final_entity", "include_all_entities", "entity_references", "entity_names")
    INCLUDE_BASE_ENTITY_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_FINAL_ENTITY_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_ALL_ENTITIES_FIELD_NUMBER: _ClassVar[int]
    ENTITY_REFERENCES_FIELD_NUMBER: _ClassVar[int]
    ENTITY_NAMES_FIELD_NUMBER: _ClassVar[int]
    include_base_entity: bool
    include_final_entity: bool
    include_all_entities: bool
    entity_references: _containers.RepeatedCompositeFieldContainer[EntityReference]
    entity_names: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, include_base_entity: _Optional[bool] = ..., include_final_entity: _Optional[bool] = ..., include_all_entities: _Optional[bool] = ..., entity_references: _Optional[_Iterable[_Union[EntityReference, _Mapping]]] = ..., entity_names: _Optional[_Iterable[str]] = ...) -> None: ...

class ObjectReferenceWithEntityFilter(_message.Message):
    __slots__ = ("reference", "entity_filter")
    REFERENCE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FILTER_FIELD_NUMBER: _ClassVar[int]
    reference: ObjectReference
    entity_filter: ObjectEntityFilter
    def __init__(self, reference: _Optional[_Union[ObjectReference, _Mapping]] = ..., entity_filter: _Optional[_Union[ObjectEntityFilter, _Mapping]] = ...) -> None: ...
