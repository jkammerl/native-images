import datetime

from google.api import annotations_pb2 as _annotations_pb2
from google.protobuf import any_pb2 as _any_pb2
from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.rpc import status_pb2 as _status_pb2
from intrinsic.icon.proto import cart_space_pb2 as _cart_space_pb2
from intrinsic.kinematics.types import joint_limits_pb2 as _joint_limits_pb2
from intrinsic.math.proto import pose_pb2 as _pose_pb2
from intrinsic.skills.proto import footprint_pb2 as _footprint_pb2
from intrinsic.world.proto import collision_settings_pb2 as _collision_settings_pb2
from intrinsic.world.proto import geometry_component_pb2 as _geometry_component_pb2
from intrinsic.world.proto import gripper_component_pb2 as _gripper_component_pb2
from intrinsic.world.proto import kinematics_component_pb2 as _kinematics_component_pb2
from intrinsic.world.proto import object_world_refs_pb2 as _object_world_refs_pb2
from intrinsic.world.proto import object_world_updates_pb2 as _object_world_updates_pb2
from intrinsic.world.proto import physics_component_pb2 as _physics_component_pb2
from intrinsic.world.proto import robot_payload_pb2 as _robot_payload_pb2
from intrinsic.world.proto import sensor_component_pb2 as _sensor_component_pb2
from intrinsic.world.proto import simulation_component_pb2 as _simulation_component_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ObjectType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OBJECT_TYPE_UNSPECIFIED: _ClassVar[ObjectType]
    ROOT: _ClassVar[ObjectType]
    PHYSICAL_OBJECT: _ClassVar[ObjectType]
    KINEMATIC_OBJECT: _ClassVar[ObjectType]
OBJECT_TYPE_UNSPECIFIED: ObjectType
ROOT: ObjectType
PHYSICAL_OBJECT: ObjectType
KINEMATIC_OBJECT: ObjectType

class WorldMetadata(_message.Message):
    __slots__ = ("id", "world_structure_hash", "last_update", "user_tag")
    ID_FIELD_NUMBER: _ClassVar[int]
    WORLD_STRUCTURE_HASH_FIELD_NUMBER: _ClassVar[int]
    LAST_UPDATE_FIELD_NUMBER: _ClassVar[int]
    USER_TAG_FIELD_NUMBER: _ClassVar[int]
    id: str
    world_structure_hash: str
    last_update: _timestamp_pb2.Timestamp
    user_tag: str
    def __init__(self, id: _Optional[str] = ..., world_structure_hash: _Optional[str] = ..., last_update: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., user_tag: _Optional[str] = ...) -> None: ...

class ObjectComponent(_message.Message):
    __slots__ = ("parent_t_this", "simulation_component", "gripper_component", "user_data")
    class UserDataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _any_pb2.Any
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_any_pb2.Any, _Mapping]] = ...) -> None: ...
    PARENT_T_THIS_FIELD_NUMBER: _ClassVar[int]
    SIMULATION_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    GRIPPER_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    USER_DATA_FIELD_NUMBER: _ClassVar[int]
    parent_t_this: _pose_pb2.Pose
    simulation_component: _simulation_component_pb2.SimulationComponent
    gripper_component: _gripper_component_pb2.GripperComponent
    user_data: _containers.MessageMap[str, _any_pb2.Any]
    def __init__(self, parent_t_this: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., simulation_component: _Optional[_Union[_simulation_component_pb2.SimulationComponent, _Mapping]] = ..., gripper_component: _Optional[_Union[_gripper_component_pb2.GripperComponent, _Mapping]] = ..., user_data: _Optional[_Mapping[str, _any_pb2.Any]] = ...) -> None: ...

class IdAndName(_message.Message):
    __slots__ = ("id", "name")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ...) -> None: ...

class KinematicObjectComponent(_message.Message):
    __slots__ = ("joint_positions", "joint_system_limits", "joint_application_limits", "joint_entity_ids", "iso_flange_frames", "named_joint_configurations", "cartesian_limits", "control_frequency_hz", "mounted_payload", "ik_solvers", "are_kinematics_updated")
    class IkSolver(_message.Message):
        __slots__ = ("kinematic_solver_key", "base_entity_id", "tip_entity_id")
        KINEMATIC_SOLVER_KEY_FIELD_NUMBER: _ClassVar[int]
        BASE_ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
        TIP_ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
        kinematic_solver_key: str
        base_entity_id: str
        tip_entity_id: str
        def __init__(self, kinematic_solver_key: _Optional[str] = ..., base_entity_id: _Optional[str] = ..., tip_entity_id: _Optional[str] = ...) -> None: ...
    JOINT_POSITIONS_FIELD_NUMBER: _ClassVar[int]
    JOINT_SYSTEM_LIMITS_FIELD_NUMBER: _ClassVar[int]
    JOINT_APPLICATION_LIMITS_FIELD_NUMBER: _ClassVar[int]
    JOINT_ENTITY_IDS_FIELD_NUMBER: _ClassVar[int]
    ISO_FLANGE_FRAMES_FIELD_NUMBER: _ClassVar[int]
    NAMED_JOINT_CONFIGURATIONS_FIELD_NUMBER: _ClassVar[int]
    CARTESIAN_LIMITS_FIELD_NUMBER: _ClassVar[int]
    CONTROL_FREQUENCY_HZ_FIELD_NUMBER: _ClassVar[int]
    MOUNTED_PAYLOAD_FIELD_NUMBER: _ClassVar[int]
    IK_SOLVERS_FIELD_NUMBER: _ClassVar[int]
    ARE_KINEMATICS_UPDATED_FIELD_NUMBER: _ClassVar[int]
    joint_positions: _containers.RepeatedScalarFieldContainer[float]
    joint_system_limits: _joint_limits_pb2.JointLimits
    joint_application_limits: _joint_limits_pb2.JointLimits
    joint_entity_ids: _containers.RepeatedScalarFieldContainer[str]
    iso_flange_frames: _containers.RepeatedCompositeFieldContainer[IdAndName]
    named_joint_configurations: _containers.RepeatedCompositeFieldContainer[_object_world_updates_pb2.NamedJointConfiguration]
    cartesian_limits: _cart_space_pb2.CartesianLimits
    control_frequency_hz: float
    mounted_payload: _robot_payload_pb2.RobotPayload
    ik_solvers: _containers.RepeatedCompositeFieldContainer[KinematicObjectComponent.IkSolver]
    are_kinematics_updated: bool
    def __init__(self, joint_positions: _Optional[_Iterable[float]] = ..., joint_system_limits: _Optional[_Union[_joint_limits_pb2.JointLimits, _Mapping]] = ..., joint_application_limits: _Optional[_Union[_joint_limits_pb2.JointLimits, _Mapping]] = ..., joint_entity_ids: _Optional[_Iterable[str]] = ..., iso_flange_frames: _Optional[_Iterable[_Union[IdAndName, _Mapping]]] = ..., named_joint_configurations: _Optional[_Iterable[_Union[_object_world_updates_pb2.NamedJointConfiguration, _Mapping]]] = ..., cartesian_limits: _Optional[_Union[_cart_space_pb2.CartesianLimits, _Mapping]] = ..., control_frequency_hz: _Optional[float] = ..., mounted_payload: _Optional[_Union[_robot_payload_pb2.RobotPayload, _Mapping]] = ..., ik_solvers: _Optional[_Iterable[_Union[KinematicObjectComponent.IkSolver, _Mapping]]] = ..., are_kinematics_updated: _Optional[bool] = ...) -> None: ...

class Object(_message.Message):
    __slots__ = ("world_id", "id", "name", "name_is_global_alias", "object_full_path", "type", "parent", "parent_entity", "children", "frames", "object_component", "kinematic_object_component", "entities", "root_entity_id")
    class EntitiesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: Entity
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[Entity, _Mapping]] = ...) -> None: ...
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_IS_GLOBAL_ALIAS_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FULL_PATH_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    PARENT_FIELD_NUMBER: _ClassVar[int]
    PARENT_ENTITY_FIELD_NUMBER: _ClassVar[int]
    CHILDREN_FIELD_NUMBER: _ClassVar[int]
    FRAMES_FIELD_NUMBER: _ClassVar[int]
    OBJECT_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    KINEMATIC_OBJECT_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    ROOT_ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    id: str
    name: str
    name_is_global_alias: bool
    object_full_path: ObjectFullPath
    type: ObjectType
    parent: IdAndName
    parent_entity: _object_world_refs_pb2.EntityReference
    children: _containers.RepeatedCompositeFieldContainer[IdAndName]
    frames: _containers.RepeatedCompositeFieldContainer[Frame]
    object_component: ObjectComponent
    kinematic_object_component: KinematicObjectComponent
    entities: _containers.MessageMap[str, Entity]
    root_entity_id: str
    def __init__(self, world_id: _Optional[str] = ..., id: _Optional[str] = ..., name: _Optional[str] = ..., name_is_global_alias: _Optional[bool] = ..., object_full_path: _Optional[_Union[ObjectFullPath, _Mapping]] = ..., type: _Optional[_Union[ObjectType, str]] = ..., parent: _Optional[_Union[IdAndName, _Mapping]] = ..., parent_entity: _Optional[_Union[_object_world_refs_pb2.EntityReference, _Mapping]] = ..., children: _Optional[_Iterable[_Union[IdAndName, _Mapping]]] = ..., frames: _Optional[_Iterable[_Union[Frame, _Mapping]]] = ..., object_component: _Optional[_Union[ObjectComponent, _Mapping]] = ..., kinematic_object_component: _Optional[_Union[KinematicObjectComponent, _Mapping]] = ..., entities: _Optional[_Mapping[str, Entity]] = ..., root_entity_id: _Optional[str] = ...) -> None: ...

class Objects(_message.Message):
    __slots__ = ("objects",)
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    objects: _containers.RepeatedCompositeFieldContainer[Object]
    def __init__(self, objects: _Optional[_Iterable[_Union[Object, _Mapping]]] = ...) -> None: ...

class Entity(_message.Message):
    __slots__ = ("world_id", "id", "name", "object", "parent_id", "parent_t_this", "geometry_component", "physics_component", "kinematics_component", "sensor_component")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    PARENT_ID_FIELD_NUMBER: _ClassVar[int]
    PARENT_T_THIS_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    PHYSICS_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    KINEMATICS_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    SENSOR_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    id: str
    name: str
    object: IdAndName
    parent_id: str
    parent_t_this: _pose_pb2.Pose
    geometry_component: _geometry_component_pb2.GeometryComponent
    physics_component: _physics_component_pb2.PhysicsComponent
    kinematics_component: _kinematics_component_pb2.KinematicsComponent
    sensor_component: _sensor_component_pb2.SensorComponent
    def __init__(self, world_id: _Optional[str] = ..., id: _Optional[str] = ..., name: _Optional[str] = ..., object: _Optional[_Union[IdAndName, _Mapping]] = ..., parent_id: _Optional[str] = ..., parent_t_this: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., geometry_component: _Optional[_Union[_geometry_component_pb2.GeometryComponent, _Mapping]] = ..., physics_component: _Optional[_Union[_physics_component_pb2.PhysicsComponent, _Mapping]] = ..., kinematics_component: _Optional[_Union[_kinematics_component_pb2.KinematicsComponent, _Mapping]] = ..., sensor_component: _Optional[_Union[_sensor_component_pb2.SensorComponent, _Mapping]] = ...) -> None: ...

class Frame(_message.Message):
    __slots__ = ("world_id", "id", "name", "object", "object_full_path", "parent_frame", "child_frames", "parent_t_this", "is_attachment_frame")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FULL_PATH_FIELD_NUMBER: _ClassVar[int]
    PARENT_FRAME_FIELD_NUMBER: _ClassVar[int]
    CHILD_FRAMES_FIELD_NUMBER: _ClassVar[int]
    PARENT_T_THIS_FIELD_NUMBER: _ClassVar[int]
    IS_ATTACHMENT_FRAME_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    id: str
    name: str
    object: IdAndName
    object_full_path: ObjectFullPath
    parent_frame: IdAndName
    child_frames: _containers.RepeatedCompositeFieldContainer[IdAndName]
    parent_t_this: _pose_pb2.Pose
    is_attachment_frame: bool
    def __init__(self, world_id: _Optional[str] = ..., id: _Optional[str] = ..., name: _Optional[str] = ..., object: _Optional[_Union[IdAndName, _Mapping]] = ..., object_full_path: _Optional[_Union[ObjectFullPath, _Mapping]] = ..., parent_frame: _Optional[_Union[IdAndName, _Mapping]] = ..., child_frames: _Optional[_Iterable[_Union[IdAndName, _Mapping]]] = ..., parent_t_this: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., is_attachment_frame: _Optional[bool] = ...) -> None: ...

class World(_message.Message):
    __slots__ = ("world_metadata", "objects", "collision_settings")
    WORLD_METADATA_FIELD_NUMBER: _ClassVar[int]
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    COLLISION_SETTINGS_FIELD_NUMBER: _ClassVar[int]
    world_metadata: WorldMetadata
    objects: _containers.RepeatedCompositeFieldContainer[Object]
    collision_settings: _collision_settings_pb2.CollisionSettings
    def __init__(self, world_metadata: _Optional[_Union[WorldMetadata, _Mapping]] = ..., objects: _Optional[_Iterable[_Union[Object, _Mapping]]] = ..., collision_settings: _Optional[_Union[_collision_settings_pb2.CollisionSettings, _Mapping]] = ...) -> None: ...

class GetWorldRequest(_message.Message):
    __slots__ = ("world_id",)
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    def __init__(self, world_id: _Optional[str] = ...) -> None: ...

class CloneWorldRequest(_message.Message):
    __slots__ = ("world_id", "cloned_world_id", "allow_overwrite", "user_tag")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    CLONED_WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    ALLOW_OVERWRITE_FIELD_NUMBER: _ClassVar[int]
    USER_TAG_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    cloned_world_id: str
    allow_overwrite: bool
    user_tag: str
    def __init__(self, world_id: _Optional[str] = ..., cloned_world_id: _Optional[str] = ..., allow_overwrite: _Optional[bool] = ..., user_tag: _Optional[str] = ...) -> None: ...

class SwapWorldRequest(_message.Message):
    __slots__ = ("world_id", "target_world_id")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    target_world_id: str
    def __init__(self, world_id: _Optional[str] = ..., target_world_id: _Optional[str] = ...) -> None: ...

class DeleteWorldRequest(_message.Message):
    __slots__ = ("world_id",)
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    def __init__(self, world_id: _Optional[str] = ...) -> None: ...

class ListWorldsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListWorldsResponse(_message.Message):
    __slots__ = ("world_metadatas",)
    WORLD_METADATAS_FIELD_NUMBER: _ClassVar[int]
    world_metadatas: _containers.RepeatedCompositeFieldContainer[WorldMetadata]
    def __init__(self, world_metadatas: _Optional[_Iterable[_Union[WorldMetadata, _Mapping]]] = ...) -> None: ...

class GetCollisionSettingsRequest(_message.Message):
    __slots__ = ("world_id",)
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    def __init__(self, world_id: _Optional[str] = ...) -> None: ...

class ObjectFullPath(_message.Message):
    __slots__ = ("object_names",)
    OBJECT_NAMES_FIELD_NUMBER: _ClassVar[int]
    object_names: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, object_names: _Optional[_Iterable[str]] = ...) -> None: ...

class GetObjectRequest(_message.Message):
    __slots__ = ("world_id", "object", "resource_handle_name", "object_full_path", "view")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_HANDLE_NAME_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FULL_PATH_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    object: _object_world_refs_pb2.ObjectReference
    resource_handle_name: str
    object_full_path: ObjectFullPath
    view: _object_world_updates_pb2.ObjectView
    def __init__(self, world_id: _Optional[str] = ..., object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., resource_handle_name: _Optional[str] = ..., object_full_path: _Optional[_Union[ObjectFullPath, _Mapping]] = ..., view: _Optional[_Union[_object_world_updates_pb2.ObjectView, str]] = ...) -> None: ...

class ListObjectsRequest(_message.Message):
    __slots__ = ("world_id", "query_objects", "view")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    QUERY_OBJECTS_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    query_objects: _containers.RepeatedCompositeFieldContainer[_object_world_refs_pb2.ObjectReference]
    view: _object_world_updates_pb2.ObjectView
    def __init__(self, world_id: _Optional[str] = ..., query_objects: _Optional[_Iterable[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]]] = ..., view: _Optional[_Union[_object_world_updates_pb2.ObjectView, str]] = ...) -> None: ...

class ListObjectsResponse(_message.Message):
    __slots__ = ("objects",)
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    objects: _containers.RepeatedCompositeFieldContainer[Object]
    def __init__(self, objects: _Optional[_Iterable[_Union[Object, _Mapping]]] = ...) -> None: ...

class GetFrameRequest(_message.Message):
    __slots__ = ("world_id", "frame")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    frame: _object_world_refs_pb2.FrameReference
    def __init__(self, world_id: _Optional[str] = ..., frame: _Optional[_Union[_object_world_refs_pb2.FrameReference, _Mapping]] = ...) -> None: ...

class ListFramesRequest(_message.Message):
    __slots__ = ("world_id", "object")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    object: _object_world_refs_pb2.ObjectReference
    def __init__(self, world_id: _Optional[str] = ..., object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ...) -> None: ...

class ListFramesResponse(_message.Message):
    __slots__ = ("frames",)
    FRAMES_FIELD_NUMBER: _ClassVar[int]
    frames: _containers.RepeatedCompositeFieldContainer[Frame]
    def __init__(self, frames: _Optional[_Iterable[_Union[Frame, _Mapping]]] = ...) -> None: ...

class GetTransformRequest(_message.Message):
    __slots__ = ("world_id", "node_a", "node_a_filter", "node_b", "node_b_filter")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    NODE_A_FIELD_NUMBER: _ClassVar[int]
    NODE_A_FILTER_FIELD_NUMBER: _ClassVar[int]
    NODE_B_FIELD_NUMBER: _ClassVar[int]
    NODE_B_FILTER_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    node_a: _object_world_refs_pb2.TransformNodeReference
    node_a_filter: _object_world_refs_pb2.ObjectEntityFilter
    node_b: _object_world_refs_pb2.TransformNodeReference
    node_b_filter: _object_world_refs_pb2.ObjectEntityFilter
    def __init__(self, world_id: _Optional[str] = ..., node_a: _Optional[_Union[_object_world_refs_pb2.TransformNodeReference, _Mapping]] = ..., node_a_filter: _Optional[_Union[_object_world_refs_pb2.ObjectEntityFilter, _Mapping]] = ..., node_b: _Optional[_Union[_object_world_refs_pb2.TransformNodeReference, _Mapping]] = ..., node_b_filter: _Optional[_Union[_object_world_refs_pb2.ObjectEntityFilter, _Mapping]] = ...) -> None: ...

class GetTransformResponse(_message.Message):
    __slots__ = ("a_t_b",)
    A_T_B_FIELD_NUMBER: _ClassVar[int]
    a_t_b: _pose_pb2.Pose
    def __init__(self, a_t_b: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ...) -> None: ...

class UpdateTransformResponse(_message.Message):
    __slots__ = ("object", "frame")
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    object: Object
    frame: Frame
    def __init__(self, object: _Optional[_Union[Object, _Mapping]] = ..., frame: _Optional[_Union[Frame, _Mapping]] = ...) -> None: ...

class UpdateWorldResourcesRequest(_message.Message):
    __slots__ = ("world_id", "world_updates", "view")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    WORLD_UPDATES_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    world_updates: _object_world_updates_pb2.ObjectWorldUpdates
    view: _object_world_updates_pb2.ObjectView
    def __init__(self, world_id: _Optional[str] = ..., world_updates: _Optional[_Union[_object_world_updates_pb2.ObjectWorldUpdates, _Mapping]] = ..., view: _Optional[_Union[_object_world_updates_pb2.ObjectView, str]] = ...) -> None: ...

class UpdateWorldResourcesResponse(_message.Message):
    __slots__ = ("objects", "collision_settings")
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    COLLISION_SETTINGS_FIELD_NUMBER: _ClassVar[int]
    objects: _containers.RepeatedCompositeFieldContainer[Object]
    collision_settings: _collision_settings_pb2.CollisionSettings
    def __init__(self, objects: _Optional[_Iterable[_Union[Object, _Mapping]]] = ..., collision_settings: _Optional[_Union[_collision_settings_pb2.CollisionSettings, _Mapping]] = ...) -> None: ...

class AreFootprintsCompatibleRequest(_message.Message):
    __slots__ = ("world_id", "left_set", "right_set", "return_all_incompatible_pairs")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    LEFT_SET_FIELD_NUMBER: _ClassVar[int]
    RIGHT_SET_FIELD_NUMBER: _ClassVar[int]
    RETURN_ALL_INCOMPATIBLE_PAIRS_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    left_set: _containers.RepeatedCompositeFieldContainer[_footprint_pb2.Footprint]
    right_set: _containers.RepeatedCompositeFieldContainer[_footprint_pb2.Footprint]
    return_all_incompatible_pairs: bool
    def __init__(self, world_id: _Optional[str] = ..., left_set: _Optional[_Iterable[_Union[_footprint_pb2.Footprint, _Mapping]]] = ..., right_set: _Optional[_Iterable[_Union[_footprint_pb2.Footprint, _Mapping]]] = ..., return_all_incompatible_pairs: _Optional[bool] = ...) -> None: ...

class AreFootprintsCompatibleResponse(_message.Message):
    __slots__ = ("world_id", "pairs")
    class IncompatiblePair(_message.Message):
        __slots__ = ("left_index", "right_index", "reason")
        LEFT_INDEX_FIELD_NUMBER: _ClassVar[int]
        RIGHT_INDEX_FIELD_NUMBER: _ClassVar[int]
        REASON_FIELD_NUMBER: _ClassVar[int]
        left_index: int
        right_index: int
        reason: _status_pb2.Status
        def __init__(self, left_index: _Optional[int] = ..., right_index: _Optional[int] = ..., reason: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...) -> None: ...
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    PAIRS_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    pairs: _containers.RepeatedCompositeFieldContainer[AreFootprintsCompatibleResponse.IncompatiblePair]
    def __init__(self, world_id: _Optional[str] = ..., pairs: _Optional[_Iterable[_Union[AreFootprintsCompatibleResponse.IncompatiblePair, _Mapping]]] = ...) -> None: ...

class CompareWorldsRequest(_message.Message):
    __slots__ = ("base_world_id", "changed_world_id", "unique_id_mode", "view")
    class IdentificationMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        IDENTIFICATION_MODE_UNSPECIFIED: _ClassVar[CompareWorldsRequest.IdentificationMode]
        BY_ID: _ClassVar[CompareWorldsRequest.IdentificationMode]
        BY_NAME: _ClassVar[CompareWorldsRequest.IdentificationMode]
    IDENTIFICATION_MODE_UNSPECIFIED: CompareWorldsRequest.IdentificationMode
    BY_ID: CompareWorldsRequest.IdentificationMode
    BY_NAME: CompareWorldsRequest.IdentificationMode
    BASE_WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    CHANGED_WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    UNIQUE_ID_MODE_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    base_world_id: str
    changed_world_id: str
    unique_id_mode: CompareWorldsRequest.IdentificationMode
    view: _object_world_updates_pb2.ObjectView
    def __init__(self, base_world_id: _Optional[str] = ..., changed_world_id: _Optional[str] = ..., unique_id_mode: _Optional[_Union[CompareWorldsRequest.IdentificationMode, str]] = ..., view: _Optional[_Union[_object_world_updates_pb2.ObjectView, str]] = ...) -> None: ...

class CompareWorldsResponse(_message.Message):
    __slots__ = ("added", "removed", "modified", "added_frames", "removed_frames", "modified_frames", "base_world_objects", "changed_world_objects")
    class ModifiedObject(_message.Message):
        __slots__ = ("object", "modification")
        OBJECT_FIELD_NUMBER: _ClassVar[int]
        MODIFICATION_FIELD_NUMBER: _ClassVar[int]
        object: _object_world_refs_pb2.ObjectReference
        modification: str
        def __init__(self, object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., modification: _Optional[str] = ...) -> None: ...
    class ModifiedFrame(_message.Message):
        __slots__ = ("frame", "modification")
        FRAME_FIELD_NUMBER: _ClassVar[int]
        MODIFICATION_FIELD_NUMBER: _ClassVar[int]
        frame: Frame
        modification: str
        def __init__(self, frame: _Optional[_Union[Frame, _Mapping]] = ..., modification: _Optional[str] = ...) -> None: ...
    ADDED_FIELD_NUMBER: _ClassVar[int]
    REMOVED_FIELD_NUMBER: _ClassVar[int]
    MODIFIED_FIELD_NUMBER: _ClassVar[int]
    ADDED_FRAMES_FIELD_NUMBER: _ClassVar[int]
    REMOVED_FRAMES_FIELD_NUMBER: _ClassVar[int]
    MODIFIED_FRAMES_FIELD_NUMBER: _ClassVar[int]
    BASE_WORLD_OBJECTS_FIELD_NUMBER: _ClassVar[int]
    CHANGED_WORLD_OBJECTS_FIELD_NUMBER: _ClassVar[int]
    added: _containers.RepeatedCompositeFieldContainer[_object_world_refs_pb2.ObjectReference]
    removed: _containers.RepeatedCompositeFieldContainer[Object]
    modified: _containers.RepeatedCompositeFieldContainer[CompareWorldsResponse.ModifiedObject]
    added_frames: _containers.RepeatedCompositeFieldContainer[Frame]
    removed_frames: _containers.RepeatedCompositeFieldContainer[Frame]
    modified_frames: _containers.RepeatedCompositeFieldContainer[CompareWorldsResponse.ModifiedFrame]
    base_world_objects: _containers.RepeatedCompositeFieldContainer[Object]
    changed_world_objects: _containers.RepeatedCompositeFieldContainer[Object]
    def __init__(self, added: _Optional[_Iterable[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]]] = ..., removed: _Optional[_Iterable[_Union[Object, _Mapping]]] = ..., modified: _Optional[_Iterable[_Union[CompareWorldsResponse.ModifiedObject, _Mapping]]] = ..., added_frames: _Optional[_Iterable[_Union[Frame, _Mapping]]] = ..., removed_frames: _Optional[_Iterable[_Union[Frame, _Mapping]]] = ..., modified_frames: _Optional[_Iterable[_Union[CompareWorldsResponse.ModifiedFrame, _Mapping]]] = ..., base_world_objects: _Optional[_Iterable[_Union[Object, _Mapping]]] = ..., changed_world_objects: _Optional[_Iterable[_Union[Object, _Mapping]]] = ...) -> None: ...

class SyncObjectRequest(_message.Message):
    __slots__ = ("from_world_id", "to_world_id", "object", "frame")
    FROM_WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    TO_WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    from_world_id: str
    to_world_id: str
    object: _object_world_refs_pb2.ObjectReference
    frame: _object_world_refs_pb2.FrameReference
    def __init__(self, from_world_id: _Optional[str] = ..., to_world_id: _Optional[str] = ..., object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., frame: _Optional[_Union[_object_world_refs_pb2.FrameReference, _Mapping]] = ...) -> None: ...

class SyncObjectResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
