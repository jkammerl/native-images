from google.protobuf import any_pb2 as _any_pb2
from google.protobuf import wrappers_pb2 as _wrappers_pb2
from intrinsic.icon.proto import cart_space_pb2 as _cart_space_pb2
from intrinsic.kinematics.types import joint_limits_pb2 as _joint_limits_pb2
from intrinsic.math.proto import pose_pb2 as _pose_pb2
from intrinsic.scene.proto.v1 import scene_object_pb2 as _scene_object_pb2
from intrinsic.world.proto import collision_action_pb2 as _collision_action_pb2
from intrinsic.world.proto import collision_settings_pb2 as _collision_settings_pb2
from intrinsic.world.proto import geometry_component_pb2 as _geometry_component_pb2
from intrinsic.world.proto import object_world_refs_pb2 as _object_world_refs_pb2
from intrinsic.world.proto import physics_component_pb2 as _physics_component_pb2
from intrinsic.world.proto import robot_payload_pb2 as _robot_payload_pb2
from intrinsic.world.proto import simulation_component_pb2 as _simulation_component_pb2
from intrinsic.world.proto import user_data_pb2 as _user_data_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ObjectView(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OBJECT_VIEW_UNSPECIFIED: _ClassVar[ObjectView]
    BASIC: _ClassVar[ObjectView]
    FULL: _ClassVar[ObjectView]

class ToggleMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TOGGLE_MODE_UNSPECIFIED: _ClassVar[ToggleMode]
    TOGGLE_MODE_ENABLE: _ClassVar[ToggleMode]
    TOGGLE_MODE_DISABLE: _ClassVar[ToggleMode]
OBJECT_VIEW_UNSPECIFIED: ObjectView
BASIC: ObjectView
FULL: ObjectView
TOGGLE_MODE_UNSPECIFIED: ToggleMode
TOGGLE_MODE_ENABLE: ToggleMode
TOGGLE_MODE_DISABLE: ToggleMode

class ObjectWorldUpdate(_message.Message):
    __slots__ = ("delete_object", "update_object_name", "update_object_joints", "update_object_joint", "update_kinematic_object_properties", "update_object_properties", "update_entity_properties", "update_collision_settings", "create_frame", "delete_frame", "update_frame_name", "reparent_frame", "update_frame_properties", "update_transform", "reparent_object", "toggle_collisions")
    DELETE_OBJECT_FIELD_NUMBER: _ClassVar[int]
    UPDATE_OBJECT_NAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_OBJECT_JOINTS_FIELD_NUMBER: _ClassVar[int]
    UPDATE_OBJECT_JOINT_FIELD_NUMBER: _ClassVar[int]
    UPDATE_KINEMATIC_OBJECT_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    UPDATE_OBJECT_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ENTITY_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    UPDATE_COLLISION_SETTINGS_FIELD_NUMBER: _ClassVar[int]
    CREATE_FRAME_FIELD_NUMBER: _ClassVar[int]
    DELETE_FRAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_FRAME_NAME_FIELD_NUMBER: _ClassVar[int]
    REPARENT_FRAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_FRAME_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    UPDATE_TRANSFORM_FIELD_NUMBER: _ClassVar[int]
    REPARENT_OBJECT_FIELD_NUMBER: _ClassVar[int]
    TOGGLE_COLLISIONS_FIELD_NUMBER: _ClassVar[int]
    delete_object: DeleteObjectRequest
    update_object_name: UpdateObjectNameRequest
    update_object_joints: UpdateObjectJointsRequest
    update_object_joint: UpdateObjectJointRequest
    update_kinematic_object_properties: UpdateKinematicObjectPropertiesRequest
    update_object_properties: UpdateObjectPropertiesRequest
    update_entity_properties: UpdateEntityPropertiesRequest
    update_collision_settings: UpdateCollisionSettingsRequest
    create_frame: CreateFrameRequest
    delete_frame: DeleteFrameRequest
    update_frame_name: UpdateFrameNameRequest
    reparent_frame: ReparentFrameRequest
    update_frame_properties: UpdateFramePropertiesRequest
    update_transform: UpdateTransformRequest
    reparent_object: ReparentObjectRequest
    toggle_collisions: ToggleCollisionsRequest
    def __init__(self, delete_object: _Optional[_Union[DeleteObjectRequest, _Mapping]] = ..., update_object_name: _Optional[_Union[UpdateObjectNameRequest, _Mapping]] = ..., update_object_joints: _Optional[_Union[UpdateObjectJointsRequest, _Mapping]] = ..., update_object_joint: _Optional[_Union[UpdateObjectJointRequest, _Mapping]] = ..., update_kinematic_object_properties: _Optional[_Union[UpdateKinematicObjectPropertiesRequest, _Mapping]] = ..., update_object_properties: _Optional[_Union[UpdateObjectPropertiesRequest, _Mapping]] = ..., update_entity_properties: _Optional[_Union[UpdateEntityPropertiesRequest, _Mapping]] = ..., update_collision_settings: _Optional[_Union[UpdateCollisionSettingsRequest, _Mapping]] = ..., create_frame: _Optional[_Union[CreateFrameRequest, _Mapping]] = ..., delete_frame: _Optional[_Union[DeleteFrameRequest, _Mapping]] = ..., update_frame_name: _Optional[_Union[UpdateFrameNameRequest, _Mapping]] = ..., reparent_frame: _Optional[_Union[ReparentFrameRequest, _Mapping]] = ..., update_frame_properties: _Optional[_Union[UpdateFramePropertiesRequest, _Mapping]] = ..., update_transform: _Optional[_Union[UpdateTransformRequest, _Mapping]] = ..., reparent_object: _Optional[_Union[ReparentObjectRequest, _Mapping]] = ..., toggle_collisions: _Optional[_Union[ToggleCollisionsRequest, _Mapping]] = ...) -> None: ...

class ObjectWorldUpdates(_message.Message):
    __slots__ = ("updates",)
    UPDATES_FIELD_NUMBER: _ClassVar[int]
    updates: _containers.RepeatedCompositeFieldContainer[ObjectWorldUpdate]
    def __init__(self, updates: _Optional[_Iterable[_Union[ObjectWorldUpdate, _Mapping]]] = ...) -> None: ...

class NamedJointConfiguration(_message.Message):
    __slots__ = ("name", "joint_positions")
    NAME_FIELD_NUMBER: _ClassVar[int]
    JOINT_POSITIONS_FIELD_NUMBER: _ClassVar[int]
    name: str
    joint_positions: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, name: _Optional[str] = ..., joint_positions: _Optional[_Iterable[float]] = ...) -> None: ...

class UpdateCollisionSettingsRequest(_message.Message):
    __slots__ = ("world_id", "collision_settings")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    COLLISION_SETTINGS_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    collision_settings: _collision_settings_pb2.CollisionSettings
    def __init__(self, world_id: _Optional[str] = ..., collision_settings: _Optional[_Union[_collision_settings_pb2.CollisionSettings, _Mapping]] = ...) -> None: ...

class RobotEntityKinematicProperties(_message.Message):
    __slots__ = ("entities",)
    class Entity(_message.Message):
        __slots__ = ("entity_name", "parent_t_entity")
        ENTITY_NAME_FIELD_NUMBER: _ClassVar[int]
        PARENT_T_ENTITY_FIELD_NUMBER: _ClassVar[int]
        entity_name: str
        parent_t_entity: _pose_pb2.Pose
        def __init__(self, entity_name: _Optional[str] = ..., parent_t_entity: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ...) -> None: ...
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    entities: _containers.RepeatedCompositeFieldContainer[RobotEntityKinematicProperties.Entity]
    def __init__(self, entities: _Optional[_Iterable[_Union[RobotEntityKinematicProperties.Entity, _Mapping]]] = ...) -> None: ...

class RobotKinematicsUpdate(_message.Message):
    __slots__ = ("robot_entity_updates", "ik_solver_key")
    ROBOT_ENTITY_UPDATES_FIELD_NUMBER: _ClassVar[int]
    IK_SOLVER_KEY_FIELD_NUMBER: _ClassVar[int]
    robot_entity_updates: RobotEntityKinematicProperties
    ik_solver_key: str
    def __init__(self, robot_entity_updates: _Optional[_Union[RobotEntityKinematicProperties, _Mapping]] = ..., ik_solver_key: _Optional[str] = ...) -> None: ...

class ObjectSpecForSingleEntityObject(_message.Message):
    __slots__ = ("entity_local_name", "geometry_component")
    ENTITY_LOCAL_NAME_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    entity_local_name: str
    geometry_component: _geometry_component_pb2.GeometryComponent
    def __init__(self, entity_local_name: _Optional[str] = ..., geometry_component: _Optional[_Union[_geometry_component_pb2.GeometryComponent, _Mapping]] = ...) -> None: ...

class ObjectSpecFromSceneObject(_message.Message):
    __slots__ = ("scene_object", "user_data")
    class UserDataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    SCENE_OBJECT_FIELD_NUMBER: _ClassVar[int]
    USER_DATA_FIELD_NUMBER: _ClassVar[int]
    scene_object: _scene_object_pb2.SceneObject
    user_data: _containers.ScalarMap[str, str]
    def __init__(self, scene_object: _Optional[_Union[_scene_object_pb2.SceneObject, _Mapping]] = ..., user_data: _Optional[_Mapping[str, str]] = ...) -> None: ...

class CreateObjectRequest(_message.Message):
    __slots__ = ("world_id", "name", "name_is_global_alias", "parent_object", "parent_object_t_created_object", "action_for_object_entities", "create_single_entity_object", "create_from_scene_object", "user_data", "view")
    class UserDataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _any_pb2.Any
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_any_pb2.Any, _Mapping]] = ...) -> None: ...
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_IS_GLOBAL_ALIAS_FIELD_NUMBER: _ClassVar[int]
    PARENT_OBJECT_FIELD_NUMBER: _ClassVar[int]
    PARENT_OBJECT_T_CREATED_OBJECT_FIELD_NUMBER: _ClassVar[int]
    ACTION_FOR_OBJECT_ENTITIES_FIELD_NUMBER: _ClassVar[int]
    CREATE_SINGLE_ENTITY_OBJECT_FIELD_NUMBER: _ClassVar[int]
    CREATE_FROM_SCENE_OBJECT_FIELD_NUMBER: _ClassVar[int]
    USER_DATA_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    name: str
    name_is_global_alias: bool
    parent_object: _object_world_refs_pb2.ObjectReferenceWithEntityFilter
    parent_object_t_created_object: _pose_pb2.Pose
    action_for_object_entities: _collision_action_pb2.CollisionAction
    create_single_entity_object: ObjectSpecForSingleEntityObject
    create_from_scene_object: ObjectSpecFromSceneObject
    user_data: _containers.MessageMap[str, _any_pb2.Any]
    view: ObjectView
    def __init__(self, world_id: _Optional[str] = ..., name: _Optional[str] = ..., name_is_global_alias: _Optional[bool] = ..., parent_object: _Optional[_Union[_object_world_refs_pb2.ObjectReferenceWithEntityFilter, _Mapping]] = ..., parent_object_t_created_object: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., action_for_object_entities: _Optional[_Union[_collision_action_pb2.CollisionAction, _Mapping]] = ..., create_single_entity_object: _Optional[_Union[ObjectSpecForSingleEntityObject, _Mapping]] = ..., create_from_scene_object: _Optional[_Union[ObjectSpecFromSceneObject, _Mapping]] = ..., user_data: _Optional[_Mapping[str, _any_pb2.Any]] = ..., view: _Optional[_Union[ObjectView, str]] = ...) -> None: ...

class DeleteObjectRequest(_message.Message):
    __slots__ = ("world_id", "object", "force", "reparent_child_objects")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    FORCE_FIELD_NUMBER: _ClassVar[int]
    REPARENT_CHILD_OBJECTS_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    object: _object_world_refs_pb2.ObjectReference
    force: bool
    reparent_child_objects: bool
    def __init__(self, world_id: _Optional[str] = ..., object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., force: _Optional[bool] = ..., reparent_child_objects: _Optional[bool] = ...) -> None: ...

class UpdateObjectNameRequest(_message.Message):
    __slots__ = ("world_id", "object", "name", "name_is_global_alias", "view")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_IS_GLOBAL_ALIAS_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    object: _object_world_refs_pb2.ObjectReference
    name: str
    name_is_global_alias: bool
    view: ObjectView
    def __init__(self, world_id: _Optional[str] = ..., object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., name: _Optional[str] = ..., name_is_global_alias: _Optional[bool] = ..., view: _Optional[_Union[ObjectView, str]] = ...) -> None: ...

class ReparentObjectRequest(_message.Message):
    __slots__ = ("world_id", "object", "new_parent", "parent_object", "parent_frame", "view")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    NEW_PARENT_FIELD_NUMBER: _ClassVar[int]
    PARENT_OBJECT_FIELD_NUMBER: _ClassVar[int]
    PARENT_FRAME_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    object: _object_world_refs_pb2.ObjectReference
    new_parent: _object_world_refs_pb2.ObjectReferenceWithEntityFilter
    parent_object: _object_world_refs_pb2.ObjectReferenceWithEntityFilter
    parent_frame: _object_world_refs_pb2.FrameReference
    view: ObjectView
    def __init__(self, world_id: _Optional[str] = ..., object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., new_parent: _Optional[_Union[_object_world_refs_pb2.ObjectReferenceWithEntityFilter, _Mapping]] = ..., parent_object: _Optional[_Union[_object_world_refs_pb2.ObjectReferenceWithEntityFilter, _Mapping]] = ..., parent_frame: _Optional[_Union[_object_world_refs_pb2.FrameReference, _Mapping]] = ..., view: _Optional[_Union[ObjectView, str]] = ...) -> None: ...

class ToggleCollisionsRequest(_message.Message):
    __slots__ = ("world_id", "toggle_mode", "object_a", "object_b", "view")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    TOGGLE_MODE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_A_FIELD_NUMBER: _ClassVar[int]
    OBJECT_B_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    toggle_mode: ToggleMode
    object_a: _object_world_refs_pb2.ObjectReferenceWithEntityFilter
    object_b: _object_world_refs_pb2.ObjectReferenceWithEntityFilter
    view: ObjectView
    def __init__(self, world_id: _Optional[str] = ..., toggle_mode: _Optional[_Union[ToggleMode, str]] = ..., object_a: _Optional[_Union[_object_world_refs_pb2.ObjectReferenceWithEntityFilter, _Mapping]] = ..., object_b: _Optional[_Union[_object_world_refs_pb2.ObjectReferenceWithEntityFilter, _Mapping]] = ..., view: _Optional[_Union[ObjectView, str]] = ...) -> None: ...

class UpdateObjectJointsRequest(_message.Message):
    __slots__ = ("world_id", "object", "joint_positions", "joint_names", "joint_application_limits", "joint_system_limits", "view")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    JOINT_POSITIONS_FIELD_NUMBER: _ClassVar[int]
    JOINT_NAMES_FIELD_NUMBER: _ClassVar[int]
    JOINT_APPLICATION_LIMITS_FIELD_NUMBER: _ClassVar[int]
    JOINT_SYSTEM_LIMITS_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    object: _object_world_refs_pb2.ObjectReference
    joint_positions: _containers.RepeatedScalarFieldContainer[float]
    joint_names: _containers.RepeatedScalarFieldContainer[str]
    joint_application_limits: _joint_limits_pb2.JointLimitsUpdate
    joint_system_limits: _joint_limits_pb2.JointLimitsUpdate
    view: ObjectView
    def __init__(self, world_id: _Optional[str] = ..., object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., joint_positions: _Optional[_Iterable[float]] = ..., joint_names: _Optional[_Iterable[str]] = ..., joint_application_limits: _Optional[_Union[_joint_limits_pb2.JointLimitsUpdate, _Mapping]] = ..., joint_system_limits: _Optional[_Union[_joint_limits_pb2.JointLimitsUpdate, _Mapping]] = ..., view: _Optional[_Union[ObjectView, str]] = ...) -> None: ...

class UpdateObjectJointRequest(_message.Message):
    __slots__ = ("world_id", "object", "joint_position", "joint_name", "view")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    JOINT_POSITION_FIELD_NUMBER: _ClassVar[int]
    JOINT_NAME_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    object: _object_world_refs_pb2.ObjectReference
    joint_position: float
    joint_name: str
    view: ObjectView
    def __init__(self, world_id: _Optional[str] = ..., object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., joint_position: _Optional[float] = ..., joint_name: _Optional[str] = ..., view: _Optional[_Union[ObjectView, str]] = ...) -> None: ...

class UpdateKinematicObjectPropertiesRequest(_message.Message):
    __slots__ = ("world_id", "object", "named_joint_configurations_to_remove", "named_joint_configurations_to_set", "cartesian_limits", "mounted_payload", "robot_kinematics_update", "view")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    NAMED_JOINT_CONFIGURATIONS_TO_REMOVE_FIELD_NUMBER: _ClassVar[int]
    NAMED_JOINT_CONFIGURATIONS_TO_SET_FIELD_NUMBER: _ClassVar[int]
    CARTESIAN_LIMITS_FIELD_NUMBER: _ClassVar[int]
    MOUNTED_PAYLOAD_FIELD_NUMBER: _ClassVar[int]
    ROBOT_KINEMATICS_UPDATE_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    object: _object_world_refs_pb2.ObjectReference
    named_joint_configurations_to_remove: _containers.RepeatedScalarFieldContainer[str]
    named_joint_configurations_to_set: _containers.RepeatedCompositeFieldContainer[NamedJointConfiguration]
    cartesian_limits: _cart_space_pb2.CartesianLimits
    mounted_payload: _robot_payload_pb2.RobotPayload
    robot_kinematics_update: RobotKinematicsUpdate
    view: ObjectView
    def __init__(self, world_id: _Optional[str] = ..., object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., named_joint_configurations_to_remove: _Optional[_Iterable[str]] = ..., named_joint_configurations_to_set: _Optional[_Iterable[_Union[NamedJointConfiguration, _Mapping]]] = ..., cartesian_limits: _Optional[_Union[_cart_space_pb2.CartesianLimits, _Mapping]] = ..., mounted_payload: _Optional[_Union[_robot_payload_pb2.RobotPayload, _Mapping]] = ..., robot_kinematics_update: _Optional[_Union[RobotKinematicsUpdate, _Mapping]] = ..., view: _Optional[_Union[ObjectView, str]] = ...) -> None: ...

class UpdateObjectPropertiesRequest(_message.Message):
    __slots__ = ("world_id", "object", "simulation_component", "user_data", "view")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    OBJECT_FIELD_NUMBER: _ClassVar[int]
    SIMULATION_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    USER_DATA_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    object: _object_world_refs_pb2.ObjectReference
    simulation_component: _simulation_component_pb2.SimulationComponent
    user_data: _user_data_pb2.UpdateUserData
    view: ObjectView
    def __init__(self, world_id: _Optional[str] = ..., object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., simulation_component: _Optional[_Union[_simulation_component_pb2.SimulationComponent, _Mapping]] = ..., user_data: _Optional[_Union[_user_data_pb2.UpdateUserData, _Mapping]] = ..., view: _Optional[_Union[ObjectView, str]] = ...) -> None: ...

class UpdateEntityPropertiesRequest(_message.Message):
    __slots__ = ("world_id", "entity", "collision_action", "geometry_component", "physics_component")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    COLLISION_ACTION_FIELD_NUMBER: _ClassVar[int]
    GEOMETRY_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    PHYSICS_COMPONENT_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    entity: _object_world_refs_pb2.ObjectReferenceWithEntityFilter
    collision_action: _collision_action_pb2.CollisionAction
    geometry_component: _geometry_component_pb2.GeometryComponent
    physics_component: _physics_component_pb2.PhysicsComponent
    def __init__(self, world_id: _Optional[str] = ..., entity: _Optional[_Union[_object_world_refs_pb2.ObjectReferenceWithEntityFilter, _Mapping]] = ..., collision_action: _Optional[_Union[_collision_action_pb2.CollisionAction, _Mapping]] = ..., geometry_component: _Optional[_Union[_geometry_component_pb2.GeometryComponent, _Mapping]] = ..., physics_component: _Optional[_Union[_physics_component_pb2.PhysicsComponent, _Mapping]] = ...) -> None: ...

class CreateFrameRequest(_message.Message):
    __slots__ = ("world_id", "parent_object", "parent_frame", "parent_object_with_filter", "new_frame_name", "parent_t_new_frame", "designate_as_attachment_frame")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    PARENT_OBJECT_FIELD_NUMBER: _ClassVar[int]
    PARENT_FRAME_FIELD_NUMBER: _ClassVar[int]
    PARENT_OBJECT_WITH_FILTER_FIELD_NUMBER: _ClassVar[int]
    NEW_FRAME_NAME_FIELD_NUMBER: _ClassVar[int]
    PARENT_T_NEW_FRAME_FIELD_NUMBER: _ClassVar[int]
    DESIGNATE_AS_ATTACHMENT_FRAME_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    parent_object: _object_world_refs_pb2.ObjectReference
    parent_frame: _object_world_refs_pb2.FrameReference
    parent_object_with_filter: _object_world_refs_pb2.ObjectReferenceWithEntityFilter
    new_frame_name: str
    parent_t_new_frame: _pose_pb2.Pose
    designate_as_attachment_frame: bool
    def __init__(self, world_id: _Optional[str] = ..., parent_object: _Optional[_Union[_object_world_refs_pb2.ObjectReference, _Mapping]] = ..., parent_frame: _Optional[_Union[_object_world_refs_pb2.FrameReference, _Mapping]] = ..., parent_object_with_filter: _Optional[_Union[_object_world_refs_pb2.ObjectReferenceWithEntityFilter, _Mapping]] = ..., new_frame_name: _Optional[str] = ..., parent_t_new_frame: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., designate_as_attachment_frame: _Optional[bool] = ...) -> None: ...

class DeleteFrameRequest(_message.Message):
    __slots__ = ("world_id", "frame", "force")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    FORCE_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    frame: _object_world_refs_pb2.FrameReference
    force: bool
    def __init__(self, world_id: _Optional[str] = ..., frame: _Optional[_Union[_object_world_refs_pb2.FrameReference, _Mapping]] = ..., force: _Optional[bool] = ...) -> None: ...

class UpdateFrameNameRequest(_message.Message):
    __slots__ = ("world_id", "frame", "name")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    frame: _object_world_refs_pb2.FrameReference
    name: str
    def __init__(self, world_id: _Optional[str] = ..., frame: _Optional[_Union[_object_world_refs_pb2.FrameReference, _Mapping]] = ..., name: _Optional[str] = ...) -> None: ...

class ReparentFrameRequest(_message.Message):
    __slots__ = ("world_id", "frame", "parent_object", "parent_frame")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    PARENT_OBJECT_FIELD_NUMBER: _ClassVar[int]
    PARENT_FRAME_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    frame: _object_world_refs_pb2.FrameReference
    parent_object: _object_world_refs_pb2.ObjectReferenceWithEntityFilter
    parent_frame: _object_world_refs_pb2.FrameReference
    def __init__(self, world_id: _Optional[str] = ..., frame: _Optional[_Union[_object_world_refs_pb2.FrameReference, _Mapping]] = ..., parent_object: _Optional[_Union[_object_world_refs_pb2.ObjectReferenceWithEntityFilter, _Mapping]] = ..., parent_frame: _Optional[_Union[_object_world_refs_pb2.FrameReference, _Mapping]] = ...) -> None: ...

class UpdateFramePropertiesRequest(_message.Message):
    __slots__ = ("world_id", "frame", "is_attachment_frame")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    FRAME_FIELD_NUMBER: _ClassVar[int]
    IS_ATTACHMENT_FRAME_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    frame: _object_world_refs_pb2.FrameReference
    is_attachment_frame: _wrappers_pb2.BoolValue
    def __init__(self, world_id: _Optional[str] = ..., frame: _Optional[_Union[_object_world_refs_pb2.FrameReference, _Mapping]] = ..., is_attachment_frame: _Optional[_Union[_wrappers_pb2.BoolValue, _Mapping]] = ...) -> None: ...

class UpdateTransformRequest(_message.Message):
    __slots__ = ("world_id", "node_a", "node_a_filter", "node_b", "node_b_filter", "node_to_update", "a_t_b", "view")
    WORLD_ID_FIELD_NUMBER: _ClassVar[int]
    NODE_A_FIELD_NUMBER: _ClassVar[int]
    NODE_A_FILTER_FIELD_NUMBER: _ClassVar[int]
    NODE_B_FIELD_NUMBER: _ClassVar[int]
    NODE_B_FILTER_FIELD_NUMBER: _ClassVar[int]
    NODE_TO_UPDATE_FIELD_NUMBER: _ClassVar[int]
    A_T_B_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    world_id: str
    node_a: _object_world_refs_pb2.TransformNodeReference
    node_a_filter: _object_world_refs_pb2.ObjectEntityFilter
    node_b: _object_world_refs_pb2.TransformNodeReference
    node_b_filter: _object_world_refs_pb2.ObjectEntityFilter
    node_to_update: _object_world_refs_pb2.TransformNodeReference
    a_t_b: _pose_pb2.Pose
    view: ObjectView
    def __init__(self, world_id: _Optional[str] = ..., node_a: _Optional[_Union[_object_world_refs_pb2.TransformNodeReference, _Mapping]] = ..., node_a_filter: _Optional[_Union[_object_world_refs_pb2.ObjectEntityFilter, _Mapping]] = ..., node_b: _Optional[_Union[_object_world_refs_pb2.TransformNodeReference, _Mapping]] = ..., node_b_filter: _Optional[_Union[_object_world_refs_pb2.ObjectEntityFilter, _Mapping]] = ..., node_to_update: _Optional[_Union[_object_world_refs_pb2.TransformNodeReference, _Mapping]] = ..., a_t_b: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., view: _Optional[_Union[ObjectView, str]] = ...) -> None: ...
