from intrinsic.math.proto import matrix_pb2 as _matrix_pb2
from intrinsic.math.proto import point_pb2 as _point_pb2
from intrinsic.math.proto import pose_pb2 as _pose_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PhysicsComponent(_message.Message):
    __slots__ = ("mass_kg", "this_t_center_of_mass", "inertia", "friction", "torsional", "contact_kp", "contact_kd")
    MASS_KG_FIELD_NUMBER: _ClassVar[int]
    THIS_T_CENTER_OF_MASS_FIELD_NUMBER: _ClassVar[int]
    INERTIA_FIELD_NUMBER: _ClassVar[int]
    FRICTION_FIELD_NUMBER: _ClassVar[int]
    TORSIONAL_FIELD_NUMBER: _ClassVar[int]
    CONTACT_KP_FIELD_NUMBER: _ClassVar[int]
    CONTACT_KD_FIELD_NUMBER: _ClassVar[int]
    mass_kg: float
    this_t_center_of_mass: _pose_pb2.Pose
    inertia: _matrix_pb2.Matrixd
    friction: Friction
    torsional: Torsional
    contact_kp: float
    contact_kd: float
    def __init__(self, mass_kg: _Optional[float] = ..., this_t_center_of_mass: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., inertia: _Optional[_Union[_matrix_pb2.Matrixd, _Mapping]] = ..., friction: _Optional[_Union[Friction, _Mapping]] = ..., torsional: _Optional[_Union[Torsional, _Mapping]] = ..., contact_kp: _Optional[float] = ..., contact_kd: _Optional[float] = ...) -> None: ...

class Friction(_message.Message):
    __slots__ = ("mu", "mu2", "slip1", "slip2", "fdir1")
    MU_FIELD_NUMBER: _ClassVar[int]
    MU2_FIELD_NUMBER: _ClassVar[int]
    SLIP1_FIELD_NUMBER: _ClassVar[int]
    SLIP2_FIELD_NUMBER: _ClassVar[int]
    FDIR1_FIELD_NUMBER: _ClassVar[int]
    mu: float
    mu2: float
    slip1: float
    slip2: float
    fdir1: _point_pb2.Point
    def __init__(self, mu: _Optional[float] = ..., mu2: _Optional[float] = ..., slip1: _Optional[float] = ..., slip2: _Optional[float] = ..., fdir1: _Optional[_Union[_point_pb2.Point, _Mapping]] = ...) -> None: ...

class Torsional(_message.Message):
    __slots__ = ("coefficient", "use_patch_radius", "patch_radius", "surface_radius", "ode_slip")
    COEFFICIENT_FIELD_NUMBER: _ClassVar[int]
    USE_PATCH_RADIUS_FIELD_NUMBER: _ClassVar[int]
    PATCH_RADIUS_FIELD_NUMBER: _ClassVar[int]
    SURFACE_RADIUS_FIELD_NUMBER: _ClassVar[int]
    ODE_SLIP_FIELD_NUMBER: _ClassVar[int]
    coefficient: float
    use_patch_radius: bool
    patch_radius: float
    surface_radius: float
    ode_slip: float
    def __init__(self, coefficient: _Optional[float] = ..., use_patch_radius: _Optional[bool] = ..., patch_radius: _Optional[float] = ..., surface_radius: _Optional[float] = ..., ode_slip: _Optional[float] = ...) -> None: ...
