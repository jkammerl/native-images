from intrinsic.math.proto import matrix_pb2 as _matrix_pb2
from intrinsic.math.proto import pose_pb2 as _pose_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RobotPayload(_message.Message):
    __slots__ = ("mass_kg", "tip_t_cog", "inertia")
    MASS_KG_FIELD_NUMBER: _ClassVar[int]
    TIP_T_COG_FIELD_NUMBER: _ClassVar[int]
    INERTIA_FIELD_NUMBER: _ClassVar[int]
    mass_kg: float
    tip_t_cog: _pose_pb2.Pose
    inertia: _matrix_pb2.Matrixd
    def __init__(self, mass_kg: _Optional[float] = ..., tip_t_cog: _Optional[_Union[_pose_pb2.Pose, _Mapping]] = ..., inertia: _Optional[_Union[_matrix_pb2.Matrixd, _Mapping]] = ...) -> None: ...
