from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SensorComponent(_message.Message):
    __slots__ = ("always_on", "update_rate", "camera", "depth_camera", "force_torque", "lidar", "topic")
    class Image(_message.Message):
        __slots__ = ("width", "height", "format")
        class Format(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            FORMAT_UNSPECIFIED: _ClassVar[SensorComponent.Image.Format]
            FORMAT_R8G8B8: _ClassVar[SensorComponent.Image.Format]
            FORMAT_L8: _ClassVar[SensorComponent.Image.Format]
            FORMAT_B8G8R8: _ClassVar[SensorComponent.Image.Format]
            FORMAT_BAYER_RGGB8: _ClassVar[SensorComponent.Image.Format]
            FORMAT_BAYER_BGGR8: _ClassVar[SensorComponent.Image.Format]
            FORMAT_BAYER_GBRG8: _ClassVar[SensorComponent.Image.Format]
            FORMAT_BAYER_GRBG8: _ClassVar[SensorComponent.Image.Format]
        FORMAT_UNSPECIFIED: SensorComponent.Image.Format
        FORMAT_R8G8B8: SensorComponent.Image.Format
        FORMAT_L8: SensorComponent.Image.Format
        FORMAT_B8G8R8: SensorComponent.Image.Format
        FORMAT_BAYER_RGGB8: SensorComponent.Image.Format
        FORMAT_BAYER_BGGR8: SensorComponent.Image.Format
        FORMAT_BAYER_GBRG8: SensorComponent.Image.Format
        FORMAT_BAYER_GRBG8: SensorComponent.Image.Format
        WIDTH_FIELD_NUMBER: _ClassVar[int]
        HEIGHT_FIELD_NUMBER: _ClassVar[int]
        FORMAT_FIELD_NUMBER: _ClassVar[int]
        width: int
        height: int
        format: SensorComponent.Image.Format
        def __init__(self, width: _Optional[int] = ..., height: _Optional[int] = ..., format: _Optional[_Union[SensorComponent.Image.Format, str]] = ...) -> None: ...
    class Clip(_message.Message):
        __slots__ = ("near", "far")
        NEAR_FIELD_NUMBER: _ClassVar[int]
        FAR_FIELD_NUMBER: _ClassVar[int]
        near: float
        far: float
        def __init__(self, near: _Optional[float] = ..., far: _Optional[float] = ...) -> None: ...
    class Noise(_message.Message):
        __slots__ = ("type", "mean", "stddev", "bias_mean", "bias_stddev", "dynamic_bias_stddev", "dynamic_bias_correlation_time", "precision")
        class Type(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            TYPE_UNSPECIFIED: _ClassVar[SensorComponent.Noise.Type]
            TYPE_GAUSSIAN: _ClassVar[SensorComponent.Noise.Type]
            TYPE_GAUSSIAN_QUANTIZED: _ClassVar[SensorComponent.Noise.Type]
        TYPE_UNSPECIFIED: SensorComponent.Noise.Type
        TYPE_GAUSSIAN: SensorComponent.Noise.Type
        TYPE_GAUSSIAN_QUANTIZED: SensorComponent.Noise.Type
        TYPE_FIELD_NUMBER: _ClassVar[int]
        MEAN_FIELD_NUMBER: _ClassVar[int]
        STDDEV_FIELD_NUMBER: _ClassVar[int]
        BIAS_MEAN_FIELD_NUMBER: _ClassVar[int]
        BIAS_STDDEV_FIELD_NUMBER: _ClassVar[int]
        DYNAMIC_BIAS_STDDEV_FIELD_NUMBER: _ClassVar[int]
        DYNAMIC_BIAS_CORRELATION_TIME_FIELD_NUMBER: _ClassVar[int]
        PRECISION_FIELD_NUMBER: _ClassVar[int]
        type: SensorComponent.Noise.Type
        mean: float
        stddev: float
        bias_mean: float
        bias_stddev: float
        dynamic_bias_stddev: float
        dynamic_bias_correlation_time: float
        precision: float
        def __init__(self, type: _Optional[_Union[SensorComponent.Noise.Type, str]] = ..., mean: _Optional[float] = ..., stddev: _Optional[float] = ..., bias_mean: _Optional[float] = ..., bias_stddev: _Optional[float] = ..., dynamic_bias_stddev: _Optional[float] = ..., dynamic_bias_correlation_time: _Optional[float] = ..., precision: _Optional[float] = ...) -> None: ...
    class Noise3D(_message.Message):
        __slots__ = ("x", "y", "z")
        X_FIELD_NUMBER: _ClassVar[int]
        Y_FIELD_NUMBER: _ClassVar[int]
        Z_FIELD_NUMBER: _ClassVar[int]
        x: SensorComponent.Noise
        y: SensorComponent.Noise
        z: SensorComponent.Noise
        def __init__(self, x: _Optional[_Union[SensorComponent.Noise, _Mapping]] = ..., y: _Optional[_Union[SensorComponent.Noise, _Mapping]] = ..., z: _Optional[_Union[SensorComponent.Noise, _Mapping]] = ...) -> None: ...
    class Intrinsics(_message.Message):
        __slots__ = ("fx", "fy", "cx", "cy")
        FX_FIELD_NUMBER: _ClassVar[int]
        FY_FIELD_NUMBER: _ClassVar[int]
        CX_FIELD_NUMBER: _ClassVar[int]
        CY_FIELD_NUMBER: _ClassVar[int]
        fx: float
        fy: float
        cx: float
        cy: float
        def __init__(self, fx: _Optional[float] = ..., fy: _Optional[float] = ..., cx: _Optional[float] = ..., cy: _Optional[float] = ...) -> None: ...
    class Distortion(_message.Message):
        __slots__ = ("k1", "k2", "k3", "p1", "p2")
        K1_FIELD_NUMBER: _ClassVar[int]
        K2_FIELD_NUMBER: _ClassVar[int]
        K3_FIELD_NUMBER: _ClassVar[int]
        P1_FIELD_NUMBER: _ClassVar[int]
        P2_FIELD_NUMBER: _ClassVar[int]
        k1: float
        k2: float
        k3: float
        p1: float
        p2: float
        def __init__(self, k1: _Optional[float] = ..., k2: _Optional[float] = ..., k3: _Optional[float] = ..., p1: _Optional[float] = ..., p2: _Optional[float] = ...) -> None: ...
    class CommonCameraProperties(_message.Message):
        __slots__ = ("horizontal_fov", "image", "clip", "noise", "intrinsics", "distortion", "visibility_mask")
        HORIZONTAL_FOV_FIELD_NUMBER: _ClassVar[int]
        IMAGE_FIELD_NUMBER: _ClassVar[int]
        CLIP_FIELD_NUMBER: _ClassVar[int]
        NOISE_FIELD_NUMBER: _ClassVar[int]
        INTRINSICS_FIELD_NUMBER: _ClassVar[int]
        DISTORTION_FIELD_NUMBER: _ClassVar[int]
        VISIBILITY_MASK_FIELD_NUMBER: _ClassVar[int]
        horizontal_fov: float
        image: SensorComponent.Image
        clip: SensorComponent.Clip
        noise: SensorComponent.Noise
        intrinsics: SensorComponent.Intrinsics
        distortion: SensorComponent.Distortion
        visibility_mask: int
        def __init__(self, horizontal_fov: _Optional[float] = ..., image: _Optional[_Union[SensorComponent.Image, _Mapping]] = ..., clip: _Optional[_Union[SensorComponent.Clip, _Mapping]] = ..., noise: _Optional[_Union[SensorComponent.Noise, _Mapping]] = ..., intrinsics: _Optional[_Union[SensorComponent.Intrinsics, _Mapping]] = ..., distortion: _Optional[_Union[SensorComponent.Distortion, _Mapping]] = ..., visibility_mask: _Optional[int] = ...) -> None: ...
    class CameraPluginSpec(_message.Message):
        __slots__ = ("camera_identifier_proto", "inlined_plugin_xml")
        CAMERA_IDENTIFIER_PROTO_FIELD_NUMBER: _ClassVar[int]
        INLINED_PLUGIN_XML_FIELD_NUMBER: _ClassVar[int]
        camera_identifier_proto: str
        inlined_plugin_xml: str
        def __init__(self, camera_identifier_proto: _Optional[str] = ..., inlined_plugin_xml: _Optional[str] = ...) -> None: ...
    class Camera(_message.Message):
        __slots__ = ("properties", "camera_plugin")
        PROPERTIES_FIELD_NUMBER: _ClassVar[int]
        CAMERA_PLUGIN_FIELD_NUMBER: _ClassVar[int]
        properties: SensorComponent.CommonCameraProperties
        camera_plugin: SensorComponent.CameraPluginSpec
        def __init__(self, properties: _Optional[_Union[SensorComponent.CommonCameraProperties, _Mapping]] = ..., camera_plugin: _Optional[_Union[SensorComponent.CameraPluginSpec, _Mapping]] = ...) -> None: ...
    class DepthCamera(_message.Message):
        __slots__ = ("properties", "camera_plugin")
        PROPERTIES_FIELD_NUMBER: _ClassVar[int]
        CAMERA_PLUGIN_FIELD_NUMBER: _ClassVar[int]
        properties: SensorComponent.CommonCameraProperties
        camera_plugin: SensorComponent.CameraPluginSpec
        def __init__(self, properties: _Optional[_Union[SensorComponent.CommonCameraProperties, _Mapping]] = ..., camera_plugin: _Optional[_Union[SensorComponent.CameraPluginSpec, _Mapping]] = ...) -> None: ...
    class ForceTorqueDevicePluginSpec(_message.Message):
        __slots__ = ("force_noise", "torque_noise", "filter_cutoff_freq", "max_force_per_axis", "max_torque_per_axis")
        FORCE_NOISE_FIELD_NUMBER: _ClassVar[int]
        TORQUE_NOISE_FIELD_NUMBER: _ClassVar[int]
        FILTER_CUTOFF_FREQ_FIELD_NUMBER: _ClassVar[int]
        MAX_FORCE_PER_AXIS_FIELD_NUMBER: _ClassVar[int]
        MAX_TORQUE_PER_AXIS_FIELD_NUMBER: _ClassVar[int]
        force_noise: SensorComponent.Noise
        torque_noise: SensorComponent.Noise
        filter_cutoff_freq: float
        max_force_per_axis: float
        max_torque_per_axis: float
        def __init__(self, force_noise: _Optional[_Union[SensorComponent.Noise, _Mapping]] = ..., torque_noise: _Optional[_Union[SensorComponent.Noise, _Mapping]] = ..., filter_cutoff_freq: _Optional[float] = ..., max_force_per_axis: _Optional[float] = ..., max_torque_per_axis: _Optional[float] = ...) -> None: ...
    class ForceTorque(_message.Message):
        __slots__ = ("frame", "measure_direction", "force_torque_device_plugin", "force_noise", "torque_noise")
        class Frame(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            FRAME_UNSPECIFIED: _ClassVar[SensorComponent.ForceTorque.Frame]
            FRAME_CHILD: _ClassVar[SensorComponent.ForceTorque.Frame]
            FRAME_PARENT: _ClassVar[SensorComponent.ForceTorque.Frame]
            FRAME_SENSOR: _ClassVar[SensorComponent.ForceTorque.Frame]
        FRAME_UNSPECIFIED: SensorComponent.ForceTorque.Frame
        FRAME_CHILD: SensorComponent.ForceTorque.Frame
        FRAME_PARENT: SensorComponent.ForceTorque.Frame
        FRAME_SENSOR: SensorComponent.ForceTorque.Frame
        class MeasureDirection(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            MEASURE_DIRECTION_UNSPECIFIED: _ClassVar[SensorComponent.ForceTorque.MeasureDirection]
            MEASURE_DIRECTION_CHILD_TO_PARENT: _ClassVar[SensorComponent.ForceTorque.MeasureDirection]
            MEASURE_DIRECTION_PARENT_TO_CHILD: _ClassVar[SensorComponent.ForceTorque.MeasureDirection]
        MEASURE_DIRECTION_UNSPECIFIED: SensorComponent.ForceTorque.MeasureDirection
        MEASURE_DIRECTION_CHILD_TO_PARENT: SensorComponent.ForceTorque.MeasureDirection
        MEASURE_DIRECTION_PARENT_TO_CHILD: SensorComponent.ForceTorque.MeasureDirection
        FRAME_FIELD_NUMBER: _ClassVar[int]
        MEASURE_DIRECTION_FIELD_NUMBER: _ClassVar[int]
        FORCE_TORQUE_DEVICE_PLUGIN_FIELD_NUMBER: _ClassVar[int]
        FORCE_NOISE_FIELD_NUMBER: _ClassVar[int]
        TORQUE_NOISE_FIELD_NUMBER: _ClassVar[int]
        frame: SensorComponent.ForceTorque.Frame
        measure_direction: SensorComponent.ForceTorque.MeasureDirection
        force_torque_device_plugin: SensorComponent.ForceTorqueDevicePluginSpec
        force_noise: SensorComponent.Noise3D
        torque_noise: SensorComponent.Noise3D
        def __init__(self, frame: _Optional[_Union[SensorComponent.ForceTorque.Frame, str]] = ..., measure_direction: _Optional[_Union[SensorComponent.ForceTorque.MeasureDirection, str]] = ..., force_torque_device_plugin: _Optional[_Union[SensorComponent.ForceTorqueDevicePluginSpec, _Mapping]] = ..., force_noise: _Optional[_Union[SensorComponent.Noise3D, _Mapping]] = ..., torque_noise: _Optional[_Union[SensorComponent.Noise3D, _Mapping]] = ...) -> None: ...
    class Scan(_message.Message):
        __slots__ = ("samples", "resolution", "min_angle", "max_angle")
        SAMPLES_FIELD_NUMBER: _ClassVar[int]
        RESOLUTION_FIELD_NUMBER: _ClassVar[int]
        MIN_ANGLE_FIELD_NUMBER: _ClassVar[int]
        MAX_ANGLE_FIELD_NUMBER: _ClassVar[int]
        samples: int
        resolution: float
        min_angle: float
        max_angle: float
        def __init__(self, samples: _Optional[int] = ..., resolution: _Optional[float] = ..., min_angle: _Optional[float] = ..., max_angle: _Optional[float] = ...) -> None: ...
    class RangeFinderDevicePluginSpec(_message.Message):
        __slots__ = ()
        def __init__(self) -> None: ...
    class Range(_message.Message):
        __slots__ = ("min_distance", "max_distance", "resolution")
        MIN_DISTANCE_FIELD_NUMBER: _ClassVar[int]
        MAX_DISTANCE_FIELD_NUMBER: _ClassVar[int]
        RESOLUTION_FIELD_NUMBER: _ClassVar[int]
        min_distance: float
        max_distance: float
        resolution: float
        def __init__(self, min_distance: _Optional[float] = ..., max_distance: _Optional[float] = ..., resolution: _Optional[float] = ...) -> None: ...
    class Lidar(_message.Message):
        __slots__ = ("horizontal", "vertical", "range", "noise", "range_finder_device_plugin")
        HORIZONTAL_FIELD_NUMBER: _ClassVar[int]
        VERTICAL_FIELD_NUMBER: _ClassVar[int]
        RANGE_FIELD_NUMBER: _ClassVar[int]
        NOISE_FIELD_NUMBER: _ClassVar[int]
        RANGE_FINDER_DEVICE_PLUGIN_FIELD_NUMBER: _ClassVar[int]
        horizontal: SensorComponent.Scan
        vertical: SensorComponent.Scan
        range: SensorComponent.Range
        noise: SensorComponent.Noise
        range_finder_device_plugin: SensorComponent.RangeFinderDevicePluginSpec
        def __init__(self, horizontal: _Optional[_Union[SensorComponent.Scan, _Mapping]] = ..., vertical: _Optional[_Union[SensorComponent.Scan, _Mapping]] = ..., range: _Optional[_Union[SensorComponent.Range, _Mapping]] = ..., noise: _Optional[_Union[SensorComponent.Noise, _Mapping]] = ..., range_finder_device_plugin: _Optional[_Union[SensorComponent.RangeFinderDevicePluginSpec, _Mapping]] = ...) -> None: ...
    ALWAYS_ON_FIELD_NUMBER: _ClassVar[int]
    UPDATE_RATE_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    DEPTH_CAMERA_FIELD_NUMBER: _ClassVar[int]
    FORCE_TORQUE_FIELD_NUMBER: _ClassVar[int]
    LIDAR_FIELD_NUMBER: _ClassVar[int]
    TOPIC_FIELD_NUMBER: _ClassVar[int]
    always_on: bool
    update_rate: float
    camera: SensorComponent.Camera
    depth_camera: SensorComponent.DepthCamera
    force_torque: SensorComponent.ForceTorque
    lidar: SensorComponent.Lidar
    topic: str
    def __init__(self, always_on: _Optional[bool] = ..., update_rate: _Optional[float] = ..., camera: _Optional[_Union[SensorComponent.Camera, _Mapping]] = ..., depth_camera: _Optional[_Union[SensorComponent.DepthCamera, _Mapping]] = ..., force_torque: _Optional[_Union[SensorComponent.ForceTorque, _Mapping]] = ..., lidar: _Optional[_Union[SensorComponent.Lidar, _Mapping]] = ..., topic: _Optional[str] = ...) -> None: ...
