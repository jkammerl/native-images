from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class SimulationComponent(_message.Message):
    __slots__ = ("disabled", "is_static")
    DISABLED_FIELD_NUMBER: _ClassVar[int]
    IS_STATIC_FIELD_NUMBER: _ClassVar[int]
    disabled: bool
    is_static: bool
    def __init__(self, disabled: _Optional[bool] = ..., is_static: _Optional[bool] = ...) -> None: ...
