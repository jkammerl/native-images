from google.protobuf import any_pb2 as _any_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class UpdateUserData(_message.Message):
    __slots__ = ("user_data", "policy")
    class UpdateUserDataPolicy(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        POLICY_UNSPECIFIED: _ClassVar[UpdateUserData.UpdateUserDataPolicy]
        POLICY_INSERT: _ClassVar[UpdateUserData.UpdateUserDataPolicy]
        POLICY_INSERT_OR_UPDATE: _ClassVar[UpdateUserData.UpdateUserDataPolicy]
        POLICY_REMOVE: _ClassVar[UpdateUserData.UpdateUserDataPolicy]
        POLICY_CLEAR_AND_REPLACE: _ClassVar[UpdateUserData.UpdateUserDataPolicy]
        POLICY_CLEAR_ALL: _ClassVar[UpdateUserData.UpdateUserDataPolicy]
    POLICY_UNSPECIFIED: UpdateUserData.UpdateUserDataPolicy
    POLICY_INSERT: UpdateUserData.UpdateUserDataPolicy
    POLICY_INSERT_OR_UPDATE: UpdateUserData.UpdateUserDataPolicy
    POLICY_REMOVE: UpdateUserData.UpdateUserDataPolicy
    POLICY_CLEAR_AND_REPLACE: UpdateUserData.UpdateUserDataPolicy
    POLICY_CLEAR_ALL: UpdateUserData.UpdateUserDataPolicy
    class UserDataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _any_pb2.Any
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_any_pb2.Any, _Mapping]] = ...) -> None: ...
    USER_DATA_FIELD_NUMBER: _ClassVar[int]
    POLICY_FIELD_NUMBER: _ClassVar[int]
    user_data: _containers.MessageMap[str, _any_pb2.Any]
    policy: UpdateUserData.UpdateUserDataPolicy
    def __init__(self, user_data: _Optional[_Mapping[str, _any_pb2.Any]] = ..., policy: _Optional[_Union[UpdateUserData.UpdateUserDataPolicy, str]] = ...) -> None: ...
